# Run from RStudio by opening this file and choosing Source.
# Each analysis gets a fresh R process to release memory between stages.
args<-grep('^--file=',commandArgs(),value=TRUE)
file<-if(length(args))sub('^--file=','',args[1]) else sys.frame(1)$ofile
revision<-dirname(dirname(normalizePath(file,winslash='/')))
scripts<-c('01_discovery_robustness.R','02_spatial_diagnostics.R','03_external_evaluation.R','04_revision_figures.R','05_program_specificity.R','06_integrity_checks.R')
for(script in scripts){
  cat('Running',script,'\n')
  status<-system2(file.path(R.home('bin'),'Rscript.exe'),args=c('--vanilla',shQuote(file.path(revision,'scripts',script))),stdout=file.path(revision,'logs',paste0(script,'.stdout.log')),stderr=file.path(revision,'logs',paste0(script,'.stderr.log')))
  if(status!=0)stop('Analysis failed: ',script,'; inspect logs')
}
cat('All R analysis stages finished. Document assembly is a separate Python step.\n')
