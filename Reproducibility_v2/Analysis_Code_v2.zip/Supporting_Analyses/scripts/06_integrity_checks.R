script_file<-if(length(grep('^--file=',commandArgs())))sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]) else sys.frame(1)$ofile
REV<-dirname(dirname(normalizePath(script_file,winslash='/')));source(file.path(REV,'scripts','common.R'))
checks<-list();k<-1
check<-function(name,ok){checks[[length(checks)+1]]<<-data.table(check=name,passed=isTRUE(ok));if(!isTRUE(ok))stop(name)}
b<-fread(file.path(REV,'tables/01_corrected_priority_baseline.csv'))[cell_type=='ALL']
check('Discovery cell totals match frozen atlas',sum(unique(b[,.(sample,cells)])$cells)==25186)
a<-fread(file.path(REV,'tables/01_QC_A_B_shared_celltype_sensitivity.csv'))
check('Both-QC celltype comparisons cover all four samples',uniqueN(a$sample)==4)
old<-fread(file.path(SOURCE,'RESULTS/11_SPATIAL/11D_F_CELL_PROGRAM_ADJUSTED_CYP_AA/11D_F_CellProgram_Model_Summary.csv'))
new<-fread(file.path(REV,'tables/04_spatial_model_diagnostics.csv'))[model=='broad']
z<-merge(old[,.(sample=Spatial_Object,gene=Gene,old_R2=R2)],new,by=c('sample','gene'))
check('Original 32 broad-model R2 values reproduced',nrow(z)==32 && max(abs(z$old_R2-z$R2))<1e-10)
pb<-fread(file.path(REV,'tables/05_external_library_pseudobulk.csv'))[cell_type=='ALL']
check('External panel has four libraries per gene per cohort',all(pb[,.N,by=.(dataset,gene)]$N==4))
check('External atlas totals match frozen analyses',all(pb[gene=='Ephx2',.(n=sum(cells)),by=dataset]$n==c(28388,15747)))
dd<-fread(file.path(REV,'tables/02_broad_CYP_detectability_all_datasets.csv'))
check('Feature absence is not coded as zero detection',all(is.na(dd[feature_present==FALSE,detection])))
check('Detection percentages within range',all(dd[feature_present==TRUE,detection]>=0 & dd[feature_present==TRUE,detection]<=100))
sim<-fread(file.path(REV,'tables/01_depth_matched_equal_cell_sensitivity.csv'))
check('Common-depth strata have balanced cell counts',all(sim[,uniqueN(n_per_condition),by=.(depth,cell_type)]$V1==1))
sp<-fread(file.path(REV,'tables/03_spatial_depth_matched_sensitivity.csv'))
check('Spatial totals match 7079 retained spots',sum(fread(file.path(REV,'tables/03_spatial_capture_geometry.csv'))$spots)==7079)
check('Spatial thinning uses balanced spot counts',all(sp[,uniqueN(n_matched),by=depth]$V1==1))
gs<-fread(file.path(REV,'tables/04_alternative_refined_state_signatures.csv'))
check('Alternative mapping signatures exclude all target genes',!any(gs$gene%in%priority))
as<-fread(file.path(REV,'tables/07_target_excluded_program_associations.csv'))
check('Target-excluded associations cover all genes and sections',nrow(as)==4*8*uniqueN(as$program))
write_tab(rbindlist(checks),'08_integrity_checks')
capture.output(sessionInfo(),file=file.path(REV,'logs','Final_R_sessionInfo.txt'))
packages<-c('SeuratObject','Matrix','data.table','ggplot2','edgeR');write_tab(data.table(package=packages,version=vapply(packages,function(p)tryCatch(as.character(packageVersion(p)),error=function(e)read.dcf(file.path('C:/Users/Mustafa Khaled/AppData/Local/R/win-library/4.5',p,'DESCRIPTION'))[1,'Version']),character(1))),'08_package_versions')
cat('All',length(checks),'scientific integrity checks passed\n')
