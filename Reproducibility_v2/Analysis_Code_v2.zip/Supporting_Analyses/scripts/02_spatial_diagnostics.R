script_file<-if(length(grep('^--file=',commandArgs())))sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]) else sys.frame(1)$ofile
REV<-dirname(dirname(normalizePath(script_file,winslash='/')));source(file.path(REV,'scripts','common.R'))
cat('Preparing alternative refined-state signatures\n')
o<-readRDS(file.path(SOURCE,'CLEAN DATA','11D_C_FINAL_CORRECTED_ANNOTATED_ATLAS.rds'))
cm<-counts(o,'RNA');md<-o@meta.data;ct<-as.character(md$corrected_refined_cell_type)
norm<-log1p(cm %*% Diagonal(x=1e4/colSums(cm)))
types<-names(which(table(ct)>=50));av<-sapply(types,function(t)rowMeans(norm[,ct==t,drop=FALSE]));de<-sapply(types,function(t)rowMeans(cm[,ct==t,drop=FALSE]>0))
exclude<-fread(file.path(SOURCE,'RESULTS/11_SPATIAL/11D_E_CORRECTED_CELL_PROGRAM_MAPPING/11D_E_Excluded_Pathway_Genes.csv'))[[1]]
sig<-list()
for(j in seq_along(types)) {
  specificity<-av[,j]-rowMeans(av[,-j,drop=FALSE]);ok<-de[,j]>=.2 & !rownames(cm)%in%exclude & !grepl('^Cyp|^mt-|^Rpl|^Rps|^Gm|^Hba|^Hbb',rownames(cm)) & rownames(cm)!='Ephx2'
  ranked<-order(specificity,decreasing=TRUE);genes<-rownames(cm)[head(ranked[ok[ranked] & specificity[ranked]>0],20)]
  if(length(genes)>=5) sig[[types[j]]]<-genes
}
write_tab(rbindlist(lapply(names(sig),function(t)data.table(state=t,gene=sig[[t]]))),'04_alternative_refined_state_signatures')
stopifnot(!any(unlist(sig)%in%priority))
rm(o,cm,norm,av,de);gc()
sp<-readRDS(file.path(SOURCE,'CLEAN DATA','11D_E_CORRECTED_CELL_PROGRAM_SCORED_SPATIAL_OBJECTS.rds'))
known<-readRDS(file.path(REV,'logs','discovery_compact.rds'))$known
summ<-list();det<-list();thinall<-list();mods<-list();resout<-list();coverage<-list();k<-1;kd<-1;kt<-1;km<-1
fit<-function(X,y){X<-cbind(Intercept=1,as.matrix(X));f<-lm.fit(X,y);b<-f$coefficients;b[is.na(b)]<-0;pred<-as.vector(X%*%b);list(X=X,coef=b,pred=pred,resid=y-pred,rank=f$rank,r2=1-sum((y-pred)^2)/sum((y-mean(y))^2))}
for(s in names(sp)) {
  cat('Spatial',s,'\n');o<-sp[[s]];cm<-counts(o,'Spatial');m<-o@meta.data;lib<-as.numeric(colSums(cm));raw<-as.matrix(cm[priority,,drop=FALSE]);yall<-log1p(sweep(raw,2,lib,'/')*1e4)
  summ[[s]]<-data.table(sample=s,gene=priority,spots=ncol(cm),positive=rowSums(raw>0),detection=100*rowMeans(raw>0),mean_raw=rowMeans(raw),mean_logCP10k=rowMeans(yall),pseudobulk_CPM=1e6*rowSums(raw)/sum(lib),median_UMI=median(lib),median_features=median(m$nFeature_Spatial))
  present<-known%in%rownames(cm);v<-matrix(0,length(known),ncol(cm));v[present,]<-as.matrix(cm[known[present],,drop=FALSE]);det[[s]]<-data.table(dataset='GSE308859_spatial',sample=s,gene=known,feature_present=present,total_spots=ncol(cm),positive=rowSums(v>0),detection=100*rowMeans(v>0),raw_sum=rowSums(v))
  xy<-as.matrix(m[,c('array_col','array_row')]);h<-chull(xy);hp<-xy[c(h,h[1]),];area<-abs(sum(hp[-nrow(hp),1]*hp[-1,2]-hp[-1,1]*hp[-nrow(hp),2]))/2
  coverage[[s]]<-data.table(sample=s,spots=nrow(m),array_hull_area=area,x_range=diff(range(xy[,1])),y_range=diff(range(xy[,2])))
  norm<-log1p(cm%*%Diagonal(x=1e4/lib));refined<-sapply(sig,function(g)as.numeric(colMeans(norm[intersect(g,rownames(cm)),,drop=FALSE])))
  broad<-as.matrix(m[,grep('^Program_',names(m)),drop=FALSE]);tech<-cbind(log_UMI=log1p(lib),log_features=log1p(m$nFeature_Spatial),percent_mt=m$percent.mt)
  candidates<-list(broad=broad,technical=tech,broad_plus_technical=cbind(broad,tech),refined_plus_technical=cbind(refined,tech))
  # Six nearest neighbors for descriptive Moran I; no spot-level inferential test.
  dd<-as.matrix(dist(xy));diag(dd)<-Inf;nb<-t(apply(dd,1,function(z)order(z)[1:6]));rm(dd)
  # Contiguous 4 x 4 spatial blocks, not random spot folds.
  block<-interaction(cut(xy[,1],4,labels=FALSE),cut(xy[,2],4,labels=FALSE),drop=TRUE)
  for(g in priority) {
    y<-yall[g,]
    for(model in names(candidates)) {
      X<-candidates[[model]];ff<-fit(X,y);cv<-rep(NA_real_,length(y))
      for(b in unique(block)){test<-block==b;train<-!test;f<-fit(X[train,,drop=FALSE],y[train]);cv[test]<-as.vector(cbind(1,X[test,,drop=FALSE])%*%f$coef)}
      z<-ff$resid-mean(ff$resid);mi<-sum(z*rowMeans(matrix(z[nb],nrow=nrow(nb))))/sum(z^2)
      cv_r2<-1-sum((y-cv)^2)/sum((y-mean(y))^2)
      q<-quantile(ff$pred,c(.25,.75));vlow<-mean(ff$resid[ff$pred<=q[1]]^2);vhigh<-mean(ff$resid[ff$pred>=q[2]]^2)
      mods[[km]]<-data.table(sample=s,gene=g,model=model,n=length(y),predictors=ncol(X),rank=ff$rank,R2=ff$r2,adjusted_R2=1-(1-ff$r2)*(length(y)-1)/(length(y)-ff$rank),spatial_block_CV_R2=cv_r2,MoranI_residual=mi,abs_residual_fitted_Spearman=suppressWarnings(cor(abs(ff$resid),ff$pred,method='spearman')),residual_MSE_high_low_ratio=vhigh/vlow);km<-km+1
      if(g=='Ephx2' & model=='broad_plus_technical') resout[[s]]<-data.table(sample=s,spot=rownames(m),x=xy[,1],y=xy[,2],observed=y,fitted=ff$pred,residual=ff$resid,block=as.character(block))
    }
  }
}
write_tab(rbindlist(summ),'03_spatial_priority_metrics');write_tab(rbindlist(det),'02_broad_CYP_detectability_spatial');write_tab(rbindlist(coverage),'03_spatial_capture_geometry');modeltab<-rbindlist(mods);write_tab(modeltab,'04_spatial_model_diagnostics');write_tab(rbindlist(resout),'04_Ephx2_spatial_residuals')
for(depth in c(5000L,10000L)) {
  elig<-lapply(sp,function(o)which(o$nCount_Spatial>=depth));n<-min(lengths(elig));if(n<30)next
  for(s in names(sp)) {
    cm<-counts(sp[[s]],'Spatial');lib<-as.numeric(colSums(cm));raw<-as.matrix(cm[priority,,drop=FALSE]);arr<-array(NA_real_,c(8,100,2))
    for(b in 1:100){jj<-sample(elig[[s]],n);v<-matrix(rhyper(8*n,as.vector(raw[,jj,drop=FALSE]),rep(lib[jj],each=8)-as.vector(raw[,jj,drop=FALSE]),depth),nrow=8);arr[,b,1]<-100*rowMeans(v>0);arr[,b,2]<-rowMeans(log1p(1e4*v/depth))}
    thinall[[kt]]<-data.table(sample=s,depth=depth,eligible_spots=length(elig[[s]]),n_matched=n,gene=priority,detection_median=apply(arr[,,1],1,median),detection_MC_low=apply(arr[,,1],1,quantile,.025),detection_MC_high=apply(arr[,,1],1,quantile,.975),mean_logCP10k=apply(arr[,,2],1,mean));kt<-kt+1
  }
}
tt<-rbindlist(thinall);write_tab(tt,'03_spatial_depth_matched_sensitivity')
p<-ggplot(tt[gene=='Ephx2'],aes(sample,detection_median,color=factor(depth),group=depth))+geom_line()+geom_point()+theme_bw(12)+labs(x=NULL,y='Ephx2 positive spots after common-depth thinning (%)',color='UMIs/spot',title='Spatial Ephx2 technical sensitivity; one section per condition')
ggsave(file.path(REV,'figures','03_Ephx2_spatial_depth.png'),p,width=9,height=5,dpi=180)
p<-ggplot(modeltab,aes(model,spatial_block_CV_R2,color=sample))+geom_hline(yintercept=0,linetype=2)+geom_point(position=position_dodge(width=.5))+facet_wrap(~gene,scales='free_y')+theme_bw(10)+theme(axis.text.x=element_text(angle=45,hjust=1))+labs(x=NULL,y='Spatially blocked prediction R2',title='Model sensitivity and out-of-block performance')
ggsave(file.path(REV,'figures','04_spatial_block_prediction.png'),p,width=13,height=8,dpi=180)
cat('Spatial diagnostics completed\n')
