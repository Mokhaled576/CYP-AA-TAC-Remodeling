options(stringsAsFactors=FALSE, warn=1)
Sys.setenv(OMP_NUM_THREADS=2, OPENBLAS_NUM_THREADS=2)
.libPaths(c('C:/Users/Mustafa Khaled/AppData/Local/R/win-library/4.5', .libPaths()))
suppressPackageStartupMessages(library(SeuratObject))
suppressPackageStartupMessages(library(Matrix))
suppressPackageStartupMessages(library(data.table))
suppressPackageStartupMessages(library(ggplot2))
SOURCE <- Sys.getenv('TAC_SOURCE_DIR', unset='')
if(!nzchar(SOURCE) || !dir.exists(SOURCE)) stop('Set TAC_SOURCE_DIR to the original processed-project directory before running.')
arg <- grep('^--file=',commandArgs(),value=TRUE)
if(!exists('REV',inherits=FALSE)) REV <- if(length(arg)) dirname(dirname(normalizePath(sub('^--file=','',arg[1]),winslash='/'))) else normalizePath('.',winslash='/')
for(d in c('tables','figures','logs','documents','source_metadata')) dir.create(file.path(REV,d),recursive=TRUE,showWarnings=FALSE)
write_tab <- function(x,name) {
  x<-as.data.table(copy(x))
  if('feature_present'%in%names(x)) for(col in intersect(c('positive','detection','raw_sum'),names(x))) set(x,which(!x$feature_present),col,NA_real_)
  fwrite(x,file.path(REV,'tables',paste0(name,'.csv')))
}
counts <- function(o,assay=DefaultAssay(o)) {
  ll <- Layers(o[[assay]],search='^counts')
  if(length(ll)>1) o <- JoinLayers(o,assay=assay,layers=ll,new='counts')
  GetAssayData(o,assay=assay,layer='counts')
}
priority <- c('Cyp1b1','Cyp2j6','Cyp2j9','Cyp4f13','Cyp4f16','Cyp4f17','Cyp4f18','Ephx2')
set.seed(20261020)
