script_file<-if(length(grep('^--file=',commandArgs())))sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]) else sys.frame(1)$ofile
REV<-dirname(dirname(normalizePath(script_file,winslash='/')));source(file.path(REV,'scripts','common.R'))
suppressPackageStartupMessages(library(edgeR))
known<-readRDS(file.path(REV,'logs','discovery_compact.rds'))$known
files<-c(GSE155882='Validation/GSE155882/CLEAN DATA/V07_GSE155882_FINAL_ANNOTATED_ATLAS.rds',GSE270896='Validation/GSE270896/CLEAN DATA/V2_03_GSE270896_FINAL_VALIDATION_ATLAS.rds')
allpb<-list();allct<-list();alleffects<-list();alldet<-list();allnorm<-list();k<-1;ke<-1;kd<-1
for(ds in names(files)) {
  cat('External evaluation',ds,'\n');o<-readRDS(file.path(SOURCE,files[[ds]]));cm<-counts(o,'RNA');m<-o@meta.data;samples<-c('Sham_Rep1','Sham_Rep2','TAC_Rep1','TAC_Rep2');stopifnot(setequal(unique(m$sample_id),samples))
  ctcol<-if(ds=='GSE155882')'V07_broad_cell_type' else 'V2_final_broad_cell_type';ct<-as.character(m[[ctcol]])
  # No arbitrary pair matching. All four cross-group comparisons are retained.
  for(t in c('ALL',sort(unique(ct)))) {
    ids<-lapply(samples,function(s)which(m$sample_id==s & (t=='ALL'|ct==t)));ns<-lengths(ids)
    if(any(ns==0))next
    pb<-sapply(ids,function(j)as.numeric(rowSums(cm[,j,drop=FALSE])));rownames(pb)<-rownames(cm);colnames(pb)<-samples
    totals<-colSums(pb);nf<-calcNormFactors(DGEList(counts=pb),method='TMM')$samples$norm.factors
    norm<-sweep(pb,2,totals*nf,'/')*1e6;plain<-sweep(pb,2,totals,'/')*1e6
    if(t=='ALL') {
      write_tab(data.table(gene=rownames(pb),pb),paste0('05_',ds,'_allgene_pseudobulk_counts'))
      allnorm[[ds]]<-data.table(dataset=ds,sample=samples,cells=ns,library_size=totals,TMM_factor=nf)
    }
    for(j in 1:4) {
      allpb[[k]]<-data.table(dataset=ds,cell_type=t,sample=samples[j],gene=priority,cells=ns[j],raw_count=pb[priority,j],CPM=plain[priority,j],TMM_CPM=norm[priority,j],positive=as.numeric(rowSums(cm[priority,ids[[j]],drop=FALSE]>0)));k<-k+1
    }
    for(g in priority) {
      v<-norm[g,];vp<-plain[g,];pairs<-as.vector(outer(v[3:4],v[1:2],function(a,b)log2((a+.01)/(b+.01))))
      pos<-sapply(ids,function(j)sum(cm[g,j]>0));logfc<-log2((mean(v[3:4])+.01)/(mean(v[1:2])+.01))
      evaluable<-min(ns)>=30 & sum(pos)>=10 & sum(pos>0)==4
      alleffects[[ke]]<-data.table(dataset=ds,cell_type=t,gene=g,min_cells=min(ns),total_positive=sum(pos),min_positive=min(pos),evaluable=evaluable,mean_Sham_TMM_CPM=mean(v[1:2]),mean_TAC_TMM_CPM=mean(v[3:4]),log2FC_TMM=logfc,log2FC_CPM=log2((mean(vp[3:4])+.01)/(mean(vp[1:2])+.01)),log2FC_TMM_pseudocount1=log2((mean(v[3:4])+1)/(mean(v[1:2])+1)),crosspair1=pairs[1],crosspair2=pairs[2],crosspair3=pairs[3],crosspair4=pairs[4],all_crosspairs_same_direction=all(pairs>0)|all(pairs<0),each_TAC_vs_Sham_mean_same_direction=all(v[3:4]>mean(v[1:2]))|all(v[3:4]<mean(v[1:2])),status=if(!evaluable)'Insufficient support' else if(all(pairs>0))'Both TAC libraries above both Sham libraries' else if(all(pairs<0))'Both TAC libraries below both Sham libraries' else 'Overlapping library ranges');ke<-ke+1
    }
  }
  for(s in samples) {
    idx<-which(m$sample_id==s);present<-known%in%rownames(cm);v<-matrix(0,length(known),length(idx));v[present,]<-as.matrix(cm[known[present],idx,drop=FALSE]);alldet[[kd]]<-data.table(dataset=ds,sample=s,gene=known,feature_present=present,total_cells=length(idx),positive=rowSums(v>0),detection=100*rowMeans(v>0),raw_sum=rowSums(v));kd<-kd+1
  }
  rm(o,cm,pb,norm,plain);gc()
}
pp<-rbindlist(allpb);ee<-rbindlist(alleffects);write_tab(pp,'05_external_library_pseudobulk');write_tab(ee,'05_external_unpaired_evaluation');write_tab(rbindlist(allnorm),'05_external_TMM_factors');write_tab(rbindlist(alldet),'02_broad_CYP_detectability_external')
ee[,normalization_direction_stable:=sign(log2FC_TMM)==sign(log2FC_CPM)];write_tab(ee[cell_type=='ALL'],'05_external_headline_summary')
p<-ggplot(pp[cell_type=='ALL'],aes(sub('_Rep[12]','',sample),TMM_CPM,color=sample))+geom_point(size=2)+facet_grid(gene~dataset,scales='free_y')+theme_bw(10)+labs(x=NULL,y='TMM-normalized pseudobulk CPM',title='External evaluation; every point is a biological library')
ggsave(file.path(REV,'figures','05_external_all_library_points.png'),p,width=10,height=12,dpi=180)
cat('External evaluation completed\n')
