script_file<-if(length(grep('^--file=',commandArgs())))sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]) else sys.frame(1)$ofile
REV<-dirname(dirname(normalizePath(script_file,winslash='/')));source(file.path(REV,'scripts','common.R'))
aa<-fread(file.path(SOURCE,'RESULTS/11_SPATIAL/11D_H_FOCUSED_CYP_AA_NETWORK/11D_H_Final_AA_Gene_Sets.csv'))
me<-fread(file.path(SOURCE,'RESULTS/11_SPATIAL/11D_G_MECHANISTIC_PATHWAY_INTEGRATION/11D_G_Final_Mechanistic_Gene_Sets.csv'))
setnames(aa,'AA_Arm','program');setnames(me,'Pathway','program');gs<-rbindlist(list(aa[,context:='AA'],me[,context:='Context']))
gs[program=='CYP_Omega_Hydroxylase',program:='Cyp4_family_associated'];gs[program=='CYP_Epoxygenase',program:='Cyp2_family_associated'];gs[program=='Epoxide_Hydrolysis',program:='Epoxide_hydrolase_associated']
write_tab(gs,'07_exact_transcript_program_members')
sp<-readRDS(file.path(SOURCE,'CLEAN DATA/11B_FILTERED_NORMALIZED_SPATIAL_OBJECTS.rds'))
traj<-list();assoc<-list();k<-1;ka<-1;availability<-list()
for(s in names(sp)) {
  cm<-counts(sp[[s]],'Spatial');norm<-log1p(cm%*%Diagonal(x=1e4/colSums(cm)))
  for(pr in unique(gs$program)) {
    genes<-intersect(gs[program==pr,Gene],rownames(cm));score<-as.numeric(colMeans(norm[genes,,drop=FALSE]))
    traj[[k]]<-data.table(sample=s,program=pr,context=gs[program==pr,context][1],genes=length(genes),mean_score=mean(score));k<-k+1
    for(g in priority) {
      kept<-setdiff(genes,g);sc<-as.numeric(colMeans(norm[kept,,drop=FALSE]));yy<-as.numeric(norm[g,]);rho<-if(length(kept) && sd(sc)>0 && sd(yy)>0)cor(sc,yy,method='spearman') else NA_real_
      assoc[[ka]]<-data.table(sample=s,gene=g,program=pr,context=gs[program==pr,context][1],target_removed=g%in%genes,remaining_genes=length(kept),rho=rho);ka<-ka+1
    }
  }
}
write_tab(rbindlist(traj),'07_spatial_transcript_program_trajectories');at<-rbindlist(assoc);write_tab(at,'07_target_excluded_program_associations')
rm(sp,cm,norm);gc()
o<-readRDS(file.path(SOURCE,'CLEAN DATA/11D_C_FINAL_CORRECTED_ANNOTATED_ATLAS.rds'));cm<-counts(o,'RNA');norm<-log1p(cm%*%Diagonal(x=1e4/colSums(cm)));md<-o@meta.data;states<-list();k<-1
for(pr in unique(gs[context=='AA',program])) {
  genes<-intersect(gs[program==pr,Gene],rownames(cm));score<-as.numeric(colMeans(norm[genes,,drop=FALSE]))
  tmp<-data.table(sample=as.character(md$sample_id),cell_type=as.character(md$corrected_broad_cell_type),score=score)
  st<-tmp[,.(n=.N,mean_score=mean(score)),by=.(sample,cell_type)];st[,program:=pr];states[[k]]<-st;k<-k+1
}
st<-rbindlist(states);sh<-st[sample=='Sham',.(cell_type,program,sham_n=n,sham_score=mean_score)];st<-merge(st,sh,by=c('cell_type','program'));st[,delta:=ifelse(n>=30 & sham_n>=30,mean_score-sham_score,NA_real_)];write_tab(st,'07_celltype_program_changes_with_support')
tr<-rbindlist(traj)[context=='AA'];tr[,sample:=factor(sample,levels=c('Sham','TAC_2W','TAC_4W','TAC_6W'))]
a<-ggplot(tr,aes(sample,mean_score,group=program))+geom_line()+geom_point()+facet_wrap(~program,scales='free_y',ncol=4)+theme_bw(9)+theme(axis.text.x=element_text(angle=30,hjust=1))+labs(x=NULL,y='Mean log1p(CP10k) score',title='A  Spatial transcript program scores')
b<-ggplot(st[sample=='TAC_4W'],aes(program,cell_type,fill=delta))+geom_tile()+scale_fill_gradient2(low='#2166ac',mid='white',high='#b2182b',na.value='grey80')+theme_bw(9)+theme(axis.text.x=element_text(angle=45,hjust=1))+labs(x=NULL,y=NULL,fill='Delta score',title='B  Captured-cell four-week minus Sham',subtitle='Grey: fewer than 30 cells in either stratum')
c<-ggplot(at[sample=='TAC_4W' & context=='AA'],aes(program,gene,fill=rho))+geom_tile()+scale_fill_gradient2(low='#2166ac',mid='white',high='#b2182b',limits=c(-1,1))+theme_bw(9)+theme(axis.text.x=element_text(angle=45,hjust=1))+labs(x=NULL,y=NULL,fill='Spearman rho',title='C  Target-excluded AA score associations')
d<-ggplot(at[sample=='TAC_4W' & context=='Context'],aes(program,gene,fill=rho))+geom_tile()+scale_fill_gradient2(low='#2166ac',mid='white',high='#b2182b',limits=c(-1,1))+theme_bw(10)+theme(axis.text.x=element_text(angle=30,hjust=1))+labs(x=NULL,y=NULL,fill='Spearman rho',title='D  Target-excluded contextual score associations')
draw5<-function(){grid::grid.newpage();grid::pushViewport(grid::viewport(layout=grid::grid.layout(3,2,heights=grid::unit(c(1.3,1.5,1.1),'null'))));print(a,vp=grid::viewport(layout.pos.row=1,layout.pos.col=1:2));print(b,vp=grid::viewport(layout.pos.row=2,layout.pos.col=1));print(c,vp=grid::viewport(layout.pos.row=2,layout.pos.col=2));print(d,vp=grid::viewport(layout.pos.row=3,layout.pos.col=1:2));grid::popViewport()}
png(file.path(REV,'figures/Figure_05_Revised.png'),width=2860,height=2860,res=220);draw5();dev.off()
pdf(file.path(REV,'figures/Figure_05_Revised.pdf'),width=13,height=13);draw5();dev.off()
for(n in c('A','B','C','D'))ggsave(file.path(REV,'figures',paste0('Figure_05',n,'_Revised.png')),get(tolower(n)),width=if(n%in%c('A','D'))12 else 9,height=6,dpi=180,bg='white')
cat('Target-excluded transcript program analysis completed\n')
