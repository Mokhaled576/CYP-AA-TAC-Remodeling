script_file<-if(length(grep('^--file=',commandArgs())))sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]) else sys.frame(1)$ofile
REV<-dirname(dirname(normalizePath(script_file,winslash='/')));source(file.path(REV,'scripts','common.R'))
sink(file.path(REV,'logs','object_inventory.txt'),split=TRUE)
for(f in c('11D_C_FINAL_CORRECTED_ANNOTATED_ATLAS.rds','11D_E_CORRECTED_CELL_PROGRAM_SCORED_SPATIAL_OBJECTS.rds','04_All_Samples_With_QC_Flags.rds')) {
  cat('\nFILE',f,'\n')
  x<-readRDS(file.path(SOURCE,'CLEAN DATA',f))
  if(inherits(x,'Seurat')) x<-list(atlas=x)
  print(names(x))
  o<-x[[1]]
  print(class(o)); print(dim(o)); print(names(o@meta.data)); print(head(o@meta.data,2)); print(Assays(o)); print(Layers(o[[DefaultAssay(o)]])); print(head(colnames(o))); print(names(o@images))
  if(length(o@images)) {print(head(GetTissueCoordinates(o))); print(dim(GetTissueCoordinates(o)))}
  rm(x,o);gc()
}
capture.output(sessionInfo(),file=file.path(REV,'logs','R_sessionInfo.txt'))
sink()
