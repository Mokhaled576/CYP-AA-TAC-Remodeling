script_file<-if(length(grep('^--file=',commandArgs())))sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]) else sys.frame(1)$ofile
REV<-dirname(dirname(normalizePath(script_file,winslash='/')));source(file.path(REV,'scripts','common.R'))
cat('Loading corrected atlas\n')
o<-readRDS(file.path(SOURCE,'CLEAN DATA','11D_C_FINAL_CORRECTED_ANNOTATED_ATLAS.rds'))
c<-counts(o,'RNA'); m<-as.data.table(o@meta.data,keep.rownames='cell')
m[,sample:=as.character(sample_id)]; m[,cell_type:=as.character(corrected_broad_cell_type)]
m[,refined:=as.character(corrected_refined_cell_type)]
stopifnot(identical(m$cell,colnames(c)),identical(as.numeric(colSums(c)),as.numeric(m$nCount_RNA)))
qc<-m[,.(cells=.N,median_UMI=as.numeric(median(nCount_RNA)),median_features=as.numeric(median(nFeature_RNA)),median_mt=as.numeric(median(percent.mt)),q25_UMI=as.numeric(quantile(nCount_RNA,.25)),q75_UMI=as.numeric(quantile(nCount_RNA,.75))),by=.(sample,cell_type)]
write_tab(qc,'01_celltype_QC');write_tab(m[,.(cells=.N),by=.(sample,cell_type)][,percent:=100*cells/sum(cells),by=sample],'01_cell_composition')
raw<-as.matrix(c[priority,,drop=FALSE]); lib<-colSums(c)
calc<-function(idx,strategy,sample,ct) data.table(sample=sample,cell_type=ct,strategy=strategy,gene=priority,cells=length(idx),positive=rowSums(raw[,idx,drop=FALSE]>0),detection=100*rowMeans(raw[,idx,drop=FALSE]>0),mean_raw=rowMeans(raw[,idx,drop=FALSE]),mean_logCP10k=rowMeans(log1p(sweep(raw[,idx,drop=FALSE],2,lib[idx],'/')*1e4)),pseudobulk_CPM=1e6*rowSums(raw[,idx,drop=FALSE])/sum(lib[idx]))
base<-rbindlist(lapply(unique(m$sample),function(s) rbindlist(lapply(c('ALL',unique(m$cell_type)),function(ct){idx<-which(m$sample==s & (ct=='ALL'|m$cell_type==ct));if(length(idx))calc(idx,'Refined_B',s,ct)}))))
write_tab(base,'01_corrected_priority_baseline')
# Original strategy A membership can only be assigned corrected identities for cells shared with B.
a<-readRDS(file.path(SOURCE,'CLEAN DATA','04_All_Samples_PostQC_Singlets_List.rds'))
qa<-list(); aw<-list(); k<-1
for(s in names(a)) {
  aa<-counts(a[[s]],'RNA'); an<-colnames(aa)
  # Final atlas has one extra sample prefix from merging.
  barcode<-function(z) sub('^.*_([ACGT]+-[0-9]+)$','\\1',z)
  keep<-barcode(m$cell) %in% barcode(an) & m$sample==s
  aw[[s]]<-data.table(sample=s,strategy='Original_A_full',gene=priority,cells=ncol(aa),positive=as.numeric(rowSums(aa[priority,,drop=FALSE]>0)),detection=100*as.numeric(rowMeans(aa[priority,,drop=FALSE]>0)))
  for(ct in c('ALL',unique(m$cell_type))) {idx<-which(keep & (ct=='ALL'|m$cell_type==ct));if(length(idx)){qa[[k]]<-calc(idx,'A_B_shared_corrected_cells',s,ct);k<-k+1}}
}
write_tab(rbindlist(qa),'01_QC_A_B_shared_celltype_sensitivity');write_tab(rbindlist(aw),'01_original_A_full_detection')
rm(a,aa);gc()
# Common-depth hypergeometric thinning of each target transcript (exact marginal distribution).
# Monte Carlo ranges below are technical sensitivity ranges, never biological confidence intervals.
sim<-list();support<-list();k<-1;kk<-1
samples<-c('Sham','TAC_2W','TAC_4W','TAC_6W')
for(depth in c(1000L,2000L)) for(ct in unique(m$cell_type)) {
  ids<-lapply(samples,function(s)which(m$sample==s & m$cell_type==ct & lib>=depth));names(ids)<-samples
  ns<-lengths(ids);support[[kk]]<-data.table(depth=depth,cell_type=ct,sample=samples,eligible=ns,balanced_n=min(ns));kk<-kk+1
  if(min(ns)<30) next
  n<-min(ns)
  for(s in samples) {
    idx<-ids[[s]]; res<-array(NA_real_,c(8,100,2))
    for(b in 1:100) {
      jj<-sample(idx,n,replace=FALSE)
      thin<-matrix(rhyper(8*n,as.vector(raw[,jj,drop=FALSE]),rep(lib[jj],each=8)-as.vector(raw[,jj,drop=FALSE]),depth),nrow=8)
      res[,b,1]<-100*rowMeans(thin>0)
      res[,b,2]<-rowMeans(log1p(1e4*thin/depth))
    }
    sim[[k]]<-data.table(depth=depth,cell_type=ct,sample=s,gene=priority,n_per_condition=n,detection_median=apply(res[,,1],1,median),detection_MC_low=apply(res[,,1],1,quantile,.025),detection_MC_high=apply(res[,,1],1,quantile,.975),mean_logCP10k=apply(res[,,2],1,mean));k<-k+1
  }
}
write_tab(rbindlist(support),'01_depth_matching_support');ss<-rbindlist(sim);write_tab(ss,'01_depth_matched_equal_cell_sensitivity')
bb<-ss[sample=='Sham',.(depth,cell_type,gene,sham_detection=detection_median,sham_log=mean_logCP10k)]
contr<-merge(ss,bb,by=c('depth','cell_type','gene'));contr[,change_detection_pp:=detection_median-sham_detection];contr[,change_logCP10k:=mean_logCP10k-sham_log];write_tab(contr,'01_depth_matched_changes_vs_Sham')
# Fixed composition standardization on cell types represented >=30 cells in every condition.
sup<-dcast(m[,.(n=.N),by=.(sample,cell_type)],cell_type~sample,value.var='n',fill=0)
common<-sup[apply(as.matrix(sup[,-1]),1,min)>=30,cell_type]
weights<-m[cell_type %in% common,.(n=.N),by=cell_type];weights[,weight:=n/sum(n)]
std<-merge(base[cell_type %in% common],weights,by='cell_type');std<-std[,.(standardized_detection=sum(detection*weight),standardized_mean_logCP10k=sum(mean_logCP10k*weight)),by=.(sample,gene)]
write_tab(weights,'01_composition_standardization_weights');write_tab(std,'01_composition_standardized_priority')
# Broad feature availability and detection, including all observed CYP features plus named AA candidates.
known<-unique(c(priority,'Cyp2c29','Cyp2c37','Cyp2c38','Cyp2c39','Cyp2c40','Cyp2c44','Cyp2c50','Cyp2c54','Cyp2c55','Cyp2c65','Cyp2c66','Cyp2c67','Cyp2c68','Cyp2c69','Cyp2c70','Cyp2j5','Cyp2j8','Cyp2j11','Cyp2j12','Cyp2j13','Cyp2u1','Cyp4a10','Cyp4a12a','Cyp4a12b','Cyp4a14',grep('^Cyp',rownames(c),value=TRUE)))
det<-list();k<-1
for(s in samples) {idx<-which(m$sample==s);present<-known%in%rownames(c);v<-matrix(0,length(known),length(idx),dimnames=list(known,NULL));v[present,]<-as.matrix(c[known[present],idx,drop=FALSE]);det[[k]]<-data.table(dataset='GSE308859_scRNA',sample=s,gene=known,feature_present=present,total_cells=length(idx),positive=rowSums(v>0),detection=100*rowMeans(v>0),raw_sum=rowSums(v));k<-k+1}
write_tab(rbindlist(det),'02_broad_CYP_detectability_discovery')
# Contribution of each captured lineage to raw Ephx2 molecules; no spatial cell-origin attribution.
ep<-copy(base[gene=='Ephx2' & cell_type!='ALL']);ep[,raw_molecules:=mean_raw*cells];ep[,raw_contribution_percent:=100*raw_molecules/sum(raw_molecules),by=sample];write_tab(ep,'03_Ephx2_captured_lineage_contributions')
saveRDS(list(known=known,refined=m[,.(cell,sample,cell_type,refined)],raw_priority=raw,lib=lib),file.path(REV,'logs','discovery_compact.rds'))
# Select focused diagnostic plots.
p<-ggplot(qc,aes(sample,median_UMI,group=cell_type,color=cell_type))+geom_line()+geom_point()+facet_wrap(~cell_type,scales='free_y',ncol=4)+guides(color='none')+theme_bw(10)+labs(x=NULL,y='Median UMIs per retained cell',title='Library complexity within corrected cell types')
ggsave(file.path(REV,'figures','01_celltype_complexity.png'),p,width=13,height=10,dpi=180)
focus<-ss[(gene=='Ephx2' & cell_type=='Endothelial cells')|(gene=='Cyp1b1' & cell_type %in% c('Endothelial cells','Fibroblasts'))|(gene=='Cyp4f18' & cell_type=='Macrophages')]
p<-ggplot(focus,aes(sample,detection_median,color=factor(depth),group=depth))+geom_line()+geom_point()+facet_wrap(~gene+cell_type,scales='free_y')+theme_bw(11)+labs(x=NULL,y='Detection after matched depth and cell number (%)',color='UMIs/cell',title='Technical sensitivity analysis; one library per condition')
ggsave(file.path(REV,'figures','02_depth_matched_priority.png'),p,width=12,height=7,dpi=180)
cat('Discovery robustness completed\n')
