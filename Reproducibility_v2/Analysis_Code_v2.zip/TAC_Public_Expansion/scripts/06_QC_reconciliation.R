options(stringsAsFactors=FALSE);Sys.setenv(TZ='UTC')
.libPaths(c('C:/Users/Mustafa Khaled/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages(library(data.table));setDTthreads(2)
a<-grep('^--file=',commandArgs(),value=TRUE);root<-if(!is.null(getOption('tac.expansion.root'))) getOption('tac.expansion.root') else if(length(a)) dirname(dirname(normalizePath(sub('^--file=','',a[1]),winslash='/'))) else normalizePath('.',winslash='/')
c<-readRDS(file.path(root,'logs','GSE120064_analysis_cache.rds'));md<-c$cellmeta
con<-gzfile(file.path(root,'data','GSE120064_TAC_raw_umi_matrix.csv.gz'),'rt')
header<-strsplit(gsub('"','',readLines(con,n=1)),',',fixed=TRUE)[[1]][-1]
mito<-list();k<-0
repeat {
 lines<-readLines(con,n=512,warn=FALSE);if(!length(lines))break
 chosen<-lines[grepl('^"?mt-',lines,ignore.case=TRUE)]
 if(length(chosen)){z<-fread(text=paste(chosen,collapse='\n'),header=FALSE);z[[1]]<-NULL;k<-k+1;mito[[k]]<-as.matrix(z)}
}
close(con);m<-do.call(rbind,mito)
md<-md[match(header,CellID)]
md[,`:=`(mitochondrial_counts=colSums(m),mitochondrial_features=colSums(m>0))]
md[,`:=`(mitochondrial_pct=100*mitochondrial_counts/observed_UMI,nuclear_counts=observed_UMI-mitochondrial_counts,nuclear_features=observed_features-mitochondrial_features)]
md[,`:=`(author_nUMI_matches_nuclear=nuclear_counts==nUMI,author_nGene_matches_nuclear=nuclear_features==nGene)]
fwrite(md,file.path(root,'results','GSE120064_QC_reconciliation_per_cell.csv'))
fwrite(md[,.(n_cells=.N,median_mito_pct=median(mitochondrial_pct),median_nuclear_counts=median(nuclear_counts),nUMI_match=sum(author_nUMI_matches_nuclear),nGene_match=sum(author_nGene_matches_nuclear)),by=.(sample,condition,CellType)],file.path(root,'results','GSE120064_QC_reconciliation_summary.csv'))
cat('Exact nuclear UMI matches:',sum(md$author_nUMI_matches_nuclear),'/',nrow(md),'\n')
cat('Exact nuclear feature matches:',sum(md$author_nGene_matches_nuclear),'/',nrow(md),'\n')
capture.output(summary(md$mitochondrial_pct),file=file.path(root,'logs','06_QC_reconciliation.txt'))
