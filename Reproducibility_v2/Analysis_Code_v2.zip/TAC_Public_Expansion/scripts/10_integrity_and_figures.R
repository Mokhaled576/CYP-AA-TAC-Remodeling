options(stringsAsFactors=FALSE);Sys.setenv(TZ='UTC')
.libPaths(c('C:/Users/Mustafa Khaled/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages(library(data.table));suppressPackageStartupMessages(library(ggplot2))
a<-grep('^--file=',commandArgs(),value=TRUE);root<-if(!is.null(getOption('tac.expansion.root'))) getOption('tac.expansion.root') else if(length(a)) dirname(dirname(normalizePath(sub('^--file=','',a[1]),winslash='/'))) else normalizePath('.',winslash='/')
read<-function(n)fread(file.path(root,'results',paste0(n,'.csv')))
out<-function(x,n)fwrite(x,file.path(root,'results',paste0(n,'.csv')))
check<-function(name,ok,details='')data.table(check=name,passed=isTRUE(ok),details=details)
qc<-read('GSE120064_cell_metadata_audited');cm<-read('GSE95140_individual_QC');hum<-read('GSE262690_patient_celltype_QC');design<-read('GSE262690_design_diagnostics');prot<-read('PXD061784_input_channel_design')
checks<-rbindlist(list(
 check('Mouse cells match metadata',nrow(qc)==11492 && !anyDuplicated(qc$CellID)),
 check('Mouse individual labels',uniqueN(qc$sample)==16),
 check('Cardiomyocyte published QC reproduced',sum(cm$n_retained)==396 && sum(cm$n_input)==482),
 check('Human published nuclei count',sum(hum$n_cells)==114288),
 check('Human patient count',uniqueN(hum$individual)==20),
 check('Human group counts',uniqueN(hum[Condition=='Control']$individual)==9 && uniqueN(hum[Condition=='AS']$individual)==11),
 check('Human all fitted designs identifiable',all(design$design_rank==design$design_columns)),
 check('Protein actual conditions balanced',all(table(prot$condition)==4)),
 check('Protein channels unique',!anyDuplicated(prot$col.name)),
 check('Ephx2 protein unique peptides',all(read('PXD061784_panel_DE_exploratory')[Gene=='Ephx2'][['Unique Peptides']]==24)),
 check('Cardiomyocyte Bulk excluded',!any(grepl('Bulk',read('GSE95140_cell_QC')$cell))),
 check('GSE120064 input byte sizes',file.info(file.path(root,'data','GSE120064_TAC_raw_umi_matrix.csv.gz'))$size==32706867 && file.info(file.path(root,'data','GSE120064_TAC_clean_cell_info_summary.txt.gz'))$size==126869),
 check('Human input byte size',file.info(file.path(root,'data','GSE262690_vandy_AS_full_processed.forDE.rds.gz'))$size==959033855)
))
out(checks,'integrity_checks');stopifnot(all(checks$passed))
mouse<-read('GSE120064_panel_TMM_CPM');cmper<-read('GSE95140_panel_individual_expression');protein<-read('PXD061784_panel_per_channel')
draw<-function(){
 par(mfrow=c(2,2),mar=c(5,5,3,1),oma=c(1,0,0,0),cex=.95)
 for(ct in c('EC','CM')){
   x<-mouse[gene=='Ephx2' & CellType==ct];lev<-c('0w','2w','5w','8w','11w');pos<-match(x$condition,lev);y<-log2(x$TMM_CPM+1)
   plot(pos,y,xlim=c(.6,5.4),ylim=range(c(0,y)),xaxt='n',pch=19,col='#216B8A',xlab='Weeks after TAC (0w baseline)',ylab='log2(TMM CPM + 1)',main=paste('GSE120064:',ct,'Ephx2'))
   axis(1,at=1:5,labels=lev);abline(v=1:5,col='#EEEEEE',lty=3)
   if(ct=='EC')mtext('5w omitted: fewer than two supported individuals',side=3,line=.1,cex=.7)
 }
 x<-cmper[strategy=='published_threshold' & gene=='Ephx2'];lev<-c('Sham','TAC_D3','TAC_W1','TAC_W2','TAC_W4','TAC_W8')
 plot(match(x$condition,lev),log2(x$mean_RPKM+1),xlim=c(.6,6.4),xaxt='n',pch=19,col='#216B8A',xlab='Condition',ylab='log2(individual mean RPKM + 1)',main='GSE95140: cardiomyocyte Ephx2');axis(1,at=1:6,labels=c('Sham','3d','1w','2w','4w','8w'));mtext('Descriptive; 3d individual 2 contains only 3 cells',side=3,line=.1,cex=.7)
 x<-protein[gene=='Ephx2'];lev<-c('Sham_1d','TAC_1d','Sham_7d','TAC_7d')
 plot(match(x$condition,lev),x$log2_median_centered,xlim=c(.6,4.4),xaxt='n',pch=19,col='#794B8D',xlab='Time-matched condition',ylab='Median-centered log2 intensity',main='PXD061784: EPHX2 protein');axis(1,at=1:4,labels=c('Sham 1d','TAC 1d','Sham 7d','TAC 7d'))
}
png(file.path(root,'figures','Figure8_Independent_Mouse_Ephx2.png'),width=1800,height=1400,res=180);draw();dev.off()
pdf(file.path(root,'figures','Figure8_Independent_Mouse_Ephx2.pdf'),width=10,height=7.8);draw();dev.off()
human<-read('GSE262690_panel_DE_exploratory')
priority<-c('EPHX2','CYP1B1','CYP2J2','CYP4A11','CYP4F2','CYP4F3')
pp<-human[gene%in%priority & CellType%in%c('Cardiomyocyte','Endothelial','Fibroblast','Macrophage')]
pp[,gene:=factor(gene,levels=priority)]
p<-ggplot(pp,aes(gene,logFC,color=model,shape=model))+geom_hline(yintercept=0,color='grey70')+geom_point(position=position_dodge(width=.6),size=2)+facet_wrap(~CellType,scales='free_y')+scale_x_discrete(drop=FALSE)+scale_color_discrete(name='Model',labels=c('Age/sex adjusted','Adjusted, AS9 excluded','Unadjusted'))+scale_shape_discrete(name='Model',labels=c('Age/sex adjusted','Adjusted, AS9 excluded','Unadjusted'))+theme_bw(base_size=11)+labs(x='Human gene',y='AS versus donor log2 fold change',caption='Patient-level pseudobulk. Missing points indicate expression filtering. Point estimates alone do not establish significance; see FDR tables.')+theme(axis.text.x=element_text(angle=40,hjust=1),legend.position='bottom')
ggsave(file.path(root,'figures','Figure9_Human_Covariate_Sensitivity.png'),p,width=11,height=8,dpi=180)
ggsave(file.path(root,'figures','Figure9_Human_Covariate_Sensitivity.pdf'),p,width=11,height=8)
cat('Integrity checks passed:',nrow(checks),'\n')
