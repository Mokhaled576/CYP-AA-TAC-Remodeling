from pathlib import Path
import openpyxl,csv,json,hashlib
r=Path(__file__).resolve().parents[1]
p=next((r/'data').glob('GSE296709*.xlsx'))
w=openpyxl.load_workbook(p,read_only=True,data_only=True);rows=w.active.iter_rows(values_only=True)
header=[next(rows) for _ in range(6)]
assert header[5][0]=='Geneid'
with (r/'results/GSE296709_source_counts.csv').open('w',newline='') as f:
 wr=csv.writer(f);wr.writerow(header[5]);wr.writerows(rows)
with (r/'results/GSE296709_sample_design.csv').open('w',newline='') as f:
 wr=csv.writer(f);wr.writerow(['sample','sample_id','condition','source_genotype','GSM','source_url'])
 for i in range(15):
  gsm='GSM'+str(8975157+i)
  wr.writerow([header[5][6+i],header[1][6+i],header[2][6+i],header[3][6+i],gsm,'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc='+gsm])
(r/'logs/GSE296709_input_provenance.json').write_text(json.dumps({'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'series':'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE296709','paper':'https://doi.org/10.1016/j.ajpath.2025.06.004','header_rows':6,'analysis_plan':'WT-labeled TAC versus Sham only; primary Ephx2/Cyp1b1; all-gene BH FDR, frozen panel coverage; no outcome-driven sample exclusion. Compare nuclear and all-gene normalization; leave-one-sample-out direction sensitivity.','limitations':'GEO WT shorthand differs from detailed inducible-control descriptions in paper. Per-sample sex unavailable. Do not infer sex-specific effects. Sorted bulk is distinct from single-cell endothelial subtype sampling.'},indent=2))
print('Extracted 15 sample count columns without editing source workbook.')
