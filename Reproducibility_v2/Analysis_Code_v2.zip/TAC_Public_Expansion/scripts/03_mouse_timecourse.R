options(stringsAsFactors=FALSE,warn=1)
Sys.setenv(TZ='UTC',OMP_NUM_THREADS=2,OPENBLAS_NUM_THREADS=2)
.libPaths(c('C:/Users/Mustafa Khaled/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages(library(data.table))
suppressPackageStartupMessages(library(Matrix))
suppressPackageStartupMessages(library(edgeR))
suppressPackageStartupMessages(library(ggplot2))
setDTthreads(2)
a<-grep('^--file=',commandArgs(),value=TRUE)
root<-if(!is.null(getOption('tac.expansion.root'))) getOption('tac.expansion.root') else if(length(a)) dirname(dirname(normalizePath(sub('^--file=','',a[1]),winslash='/'))) else normalizePath('.',winslash='/')
for(d in c('results','figures','logs'))dir.create(file.path(root,d),showWarnings=FALSE)
sink(file.path(root,'logs','03_mouse_timecourse.log'),split=TRUE)
cat('Start',format(Sys.time(),tz='UTC'),'UTC\n')
out<-function(x,n)fwrite(x,file.path(root,'results',paste0(n,'.csv')))
panel<-fread(file.path(root,'results','frozen_mouse_gene_panel.csv'))$mouse_gene
priority<-c('Cyp1b1','Cyp2j6','Cyp2j9','Cyp4f13','Cyp4f16','Cyp4f17','Cyp4f18','Ephx2')
cachefile<-file.path(root,'logs','GSE120064_analysis_cache.rds')
if(file.exists(cachefile)) {
 cached<-readRDS(cachefile);pb<-cached$counts;gr<-cached$groups;meta<-cached$cellmeta;target<-cached$target
 observedUMI<-meta$observed_UMI;observedFeatures<-meta$observed_features
 cat('Reused validated local aggregation cache.\n')
} else {
meta<-fread(text=paste(readLines(gzfile(file.path(root,'data','GSE120064_TAC_clean_cell_info_summary.txt.gz')),warn=FALSE),collapse='\n'),na.strings=NULL)
stopifnot(!anyDuplicated(meta$CellID),!anyNA(meta$sample),!anyNA(meta$condition))
meta[,condition:=factor(condition,levels=c('0w','2w','5w','8w','11w'))]
con<-gzfile(file.path(root,'data','GSE120064_TAC_raw_umi_matrix.csv.gz'),'rt')
header<-strsplit(gsub('"','',readLines(con,n=1)),',',fixed=TRUE)[[1]][-1]
stopifnot(setequal(header,meta$CellID),!anyDuplicated(header))
meta<-meta[match(header,CellID)]
meta[,group_id:=paste(sample,CellType,sep='__')]
gr<-unique(meta[,.(group_id,sample,condition,CellType)])
gr[,n_cells:=as.integer(table(factor(meta$group_id,levels=group_id)))]
inc<-sparseMatrix(i=seq_len(nrow(meta)),j=match(meta$group_id,gr$group_id),x=1,dims=c(nrow(meta),nrow(gr)))
pbblocks<-list(); genelist<-character(); targetblocks<-list(); observedUMI<-numeric(nrow(meta)); observedFeatures<-integer(nrow(meta));k<-0
repeat {
 lines<-readLines(con,n=192,warn=FALSE)
 if(!length(lines))break
 z<-fread(text=paste(lines,collapse='\n'),header=FALSE,showProgress=FALSE)
 genes<-as.character(z[[1]]);z[[1]]<-NULL;m<-as.matrix(z)
 stopifnot(ncol(m)==nrow(meta),all(is.finite(m)),all(m>=0),all(m==floor(m)))
 observedUMI<-observedUMI+colSums(m);observedFeatures<-observedFeatures+colSums(m>0)
 k<-k+1;pbblocks[[k]]<-as.matrix(m%*%inc);genelist<-c(genelist,genes)
 ix<-which(genes%in%panel)
 if(length(ix)){tt<-m[ix,,drop=FALSE];rownames(tt)<-genes[ix];targetblocks[[length(targetblocks)+1]]<-tt}
 if(k%%20==0)cat('Read genes:',length(genelist),'\n')
}
close(con)
stopifnot(!anyDuplicated(genelist))
pb<-do.call(rbind,pbblocks);rownames(pb)<-genelist;colnames(pb)<-gr$group_id
target<-do.call(rbind,targetblocks);colnames(target)<-meta$CellID
}
meta[,`:=`(observed_UMI=observedUMI,observed_features=observedFeatures)]
out(meta,'GSE120064_cell_metadata_audited')
qc<-meta[,.(n_cells=.N,median_UMI=median(observed_UMI),median_features=median(observed_features),min_UMI=min(observed_UMI)),by=.(sample,condition,CellType)]
out(qc,'GSE120064_sample_celltype_QC')
out(meta[,.N,by=.(sample,condition,group,plate_id)],'GSE120064_source_group_plate_distribution')
out(data.table(gene=rownames(pb),pb),'GSE120064_allgene_pseudobulk_counts')
cat('Read',nrow(pb),'genes and',nrow(meta),'cells across',uniqueN(meta$sample),'individual labels\n')
out(data.table(gene=panel,feature_present=panel%in%rownames(target)),'GSE120064_panel_coverage')
metrics<-rbindlist(lapply(seq_len(nrow(gr)),function(j){
 ix<-which(meta$group_id==gr$group_id[j]);v<-target[,ix,drop=FALSE]
 data.table(group_id=gr$group_id[j],gene=rownames(target),positive=rowSums(v>0),detection_pct=rowMeans(v>0)*100,
 mean_CP10k=rowMeans(sweep(v,2,observedUMI[ix],'/')*1e4),raw_sum=rowSums(v))
}))
metrics<-merge(metrics,gr,by='group_id',sort=FALSE)
out(metrics,'GSE120064_panel_per_individual')
de<-list();norms<-list();support<-list()
for(ct in setdiff(unique(gr$CellType),'NA')) {
 # Primary: published annotated cells, >=30 cells per individual/lineage.
 gi<-which(gr$CellType==ct & gr$n_cells>=30)
 g<-copy(gr[gi]);g[,condition:=droplevels(condition)]
 if(!'0w'%in%g$condition)next
 goodlevels<-names(which(table(g$condition)>=2))
 g<-g[as.character(condition)%in%goodlevels];g[,condition:=droplevels(condition)]
 if(!'0w'%in%g$condition || nlevels(g$condition)<2)next
 # Mitochondrial features are retained in raw exports but excluded from nuclear-gene DE normalization.
 cnt<-pb[!grepl('^mt-',rownames(pb),ignore.case=TRUE),g$group_id,drop=FALSE]
 design<-model.matrix(~0+condition,data=g);colnames(design)<-levels(g$condition)
 y<-DGEList(counts=cnt); keep<-filterByExpr(y,design=design)
 if(sum(keep)<100)next
 y<-calcNormFactors(y[keep,,keep.lib.sizes=FALSE],method='TMM')
 y<-estimateDisp(y,design);fit<-glmQLFit(y,design,robust=FALSE)
 # CPM for every panel gene uses the same effective libraries as the fitted model.
 eff<-y$samples$lib.size*y$samples$norm.factors
 allcpm<-sweep(cnt,2,eff,'/')*1e6
 ix<-which(rownames(cnt)%in%panel)
 norms[[ct]]<-data.table(gene=rep(rownames(cnt)[ix],times=nrow(g)),group_id=rep(g$group_id,each=length(ix)),TMM_CPM=as.vector(allcpm[ix,,drop=FALSE]))
 for(co in setdiff(levels(g$condition),'0w')) {
   contrast<-setNames(rep(0,ncol(design)),colnames(design));contrast[co]<-1;contrast['0w']<--1
   tab<-as.data.table(topTags(glmQLFTest(fit,contrast=contrast),n=Inf,sort.by='none')$table,keep.rownames='gene')
   tab[,`:=`(CellType=ct,contrast=paste0(co,'_vs_0w'),n_baseline=sum(g$condition=='0w'),n_TAC=sum(g$condition==co),panel_gene=gene%in%panel)]
   de[[paste(ct,co)]]<-tab
 }
 support[[ct]]<-g
}
allDE<-rbindlist(de,fill=TRUE);allDE[,FDR_global:=p.adjust(PValue,'BH')]
out(allDE,'GSE120064_allgene_DE_exploratory');out(allDE[panel_gene==TRUE],'GSE120064_panel_DE_exploratory')
normtab<-merge(rbindlist(norms),gr,by='group_id',sort=FALSE)
out(normtab,'GSE120064_panel_TMM_CPM');out(rbindlist(support),'GSE120064_DE_sample_support')
saveRDS(list(counts=pb,groups=gr,cellmeta=meta,target=target),file.path(root,'logs','GSE120064_analysis_cache.rds'))
p<-ggplot(normtab[gene%in%c('Ephx2','Cyp1b1','Cyp4f18') & CellType%in%c('EC','FB','MP','CM')],aes(condition,log2(TMM_CPM+1)))+geom_point(position=position_jitter(width=.1,height=0),alpha=.8,size=1.6)+stat_summary(fun=mean,geom='point',shape=18,size=2.5,color='#B34227')+facet_grid(gene~CellType,scales='free_y')+theme_bw(base_size=11)+labs(x='Weeks after TAC (0w baseline)',y='Individual pseudobulk log2(TMM CPM + 1)',caption='Each point is an individual label; >=30 cells/lineage. Red diamonds: group means. Unequal n and baseline-only controls limit inference.')
ggsave(file.path(root,'figures','GSE120064_priority_individuals.png'),p,width=12,height=8,dpi=180)
ggsave(file.path(root,'figures','GSE120064_priority_individuals.pdf'),p,width=12,height=8)
cat('Complete GSE120064. DE tests exploratory; no cells treated as independent animals.\n')
capture.output(sessionInfo(),file=file.path(root,'logs','03_R_session.txt'));sink()
