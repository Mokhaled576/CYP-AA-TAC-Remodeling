# Open Expansion.Rproj before sourcing this file in RStudio.
args<-grep('^--file=',commandArgs(),value=TRUE)
project_root<-if(length(args)) dirname(dirname(normalizePath(sub('^--file=','',args[1]),winslash='/'))) else normalizePath('.',winslash='/')
stopifnot(dir.exists(file.path(project_root,'data')),dir.exists(file.path(project_root,'scripts')))
options(tac.expansion.root=project_root)
sys.source(file.path(project_root,'scripts','00_prepare_inputs.R'),envir=new.env(parent=globalenv()))
required<-c('GSE120064_TAC_raw_umi_matrix.csv.gz','GSE120064_TAC_clean_cell_info_summary.txt.gz','GSE95140_single-cardiomyocyte_RNA-seq.txt.gz','fractionated_FP_TMT16_protein.tsv','P3464_metadata.csv','GSE262690_vandy_AS_full_processed.forDE.rds')
missing<-required[!file.exists(file.path(project_root,'data',required))]
if(length(missing))stop('Missing inputs: ',paste(missing,collapse=', '))
stopifnot(file.exists(file.path(project_root,'results','GSE262690_published_patient_covariates.csv')))
for(script in c('03_mouse_timecourse.R','04_cardiomyocyte_timecourse.R','05_proteomics.R','06_QC_reconciliation.R','08_mouse_sensitivity.R','09_human_pseudobulk.R','10_integrity_and_figures.R','11_endothelial_4week.R','12_lipidomics_3week.R')) {
 cat('\nRunning',script,'\n')
 sys.source(file.path(project_root,'scripts',script),envir=new.env(parent=globalenv()))
 gc()
}
cat('All analyses completed. See results, figures and logs.\n')
