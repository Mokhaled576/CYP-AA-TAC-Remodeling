options(stringsAsFactors=FALSE);Sys.setenv(TZ='UTC')
.libPaths(c('C:/Users/Mustafa Khaled/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages(library(data.table));suppressPackageStartupMessages(library(ggplot2))
a<-grep('^--file=',commandArgs(),value=TRUE);root<-if(!is.null(getOption('tac.expansion.root'))) getOption('tac.expansion.root') else if(length(a)) dirname(dirname(normalizePath(sub('^--file=','',a[1]),winslash='/'))) else normalizePath('.',winslash='/')
o<-readRDS(file.path(root,'logs','GSE120064_analysis_cache.rds'))
md<-fread(file.path(root,'results','GSE120064_QC_reconciliation_per_cell.csv'))
stopifnot(identical(md$CellID,colnames(o$target)),all(md$nuclear_counts>0))
out<-function(x,n)fwrite(x,file.path(root,'results',paste0(n,'.csv')))
target<-o$target
grp<-unique(md[,.(sample,condition,CellType,group)])
summ<-rbindlist(lapply(seq_len(nrow(grp)),function(j){
 g<-grp[j];ix<-which(md$sample==g$sample & md$CellType==g$CellType & md$group==g$group)
 data.table(sample=g$sample,condition=g$condition,CellType=g$CellType,source_group=g$group,gene=rownames(target),n_cells=length(ix),
 mean_nuclear_CP10k=rowMeans(sweep(target[,ix,drop=FALSE],2,md$nuclear_counts[ix],'/')*1e4),detection_pct=rowMeans(target[,ix,drop=FALSE]>0)*100)
}))
out(summ,'GSE120064_source_group_specific_target_summaries')
effects<-rbindlist(lapply(c(10L,30L,50L),function(cutoff){
 x<-summ[n_cells>=cutoff & CellType%in%c('EC','FB','MP','CM')]
 rbindlist(lapply(split(x,by=c('gene','CellType','source_group'),keep.by=TRUE),function(z){
   b<-z[condition=='0w'];if(nrow(b)<2)return(NULL)
   rbindlist(lapply(setdiff(unique(z$condition),'0w'),function(co){
     t<-z[condition==co];if(nrow(t)<2)return(NULL)
     dif<-as.vector(outer(t$mean_nuclear_CP10k,b$mean_nuclear_CP10k,'-'))
     data.table(gene=z$gene[1],CellType=z$CellType[1],source_group=z$source_group[1],min_cells=cutoff,contrast=paste0(co,'_vs_0w'),n_baseline=nrow(b),n_TAC=nrow(t),mean_baseline=mean(b$mean_nuclear_CP10k),mean_TAC=mean(t$mean_nuclear_CP10k),log2FC_pc_point01=log2((mean(t$mean_nuclear_CP10k)+.01)/(mean(b$mean_nuclear_CP10k)+.01)),detection_difference=mean(t$detection_pct)-mean(b$detection_pct),all_crosspairs_same_direction=all(dif>0)||all(dif<0))
   }))
 }))
}))
out(effects,'GSE120064_source_group_cell_support_sensitivity')
de<-fread(file.path(root,'results','GSE120064_panel_DE_exploratory.csv'))
selected<-de[(gene=='Ephx2' & CellType%in%c('EC','CM','FB')) | (gene=='Cyp1b1' & CellType%in%c('EC','FB')) | (gene=='Cyp4f18' & CellType=='MP')]
out(selected,'GSE120064_existing_hypothesis_DE_summary')
p<-ggplot(selected,aes(contrast,logFC,color=CellType))+geom_hline(yintercept=0,color='grey60')+geom_point(position=position_dodge(width=.5),size=2)+facet_wrap(~gene,scales='free_y')+theme_bw(base_size=11)+labs(x='Independent cohort comparison',y='Exploratory pseudobulk log2 fold change',caption='Nuclear-gene TMM normalization; >=30 cells/individual/lineage. Missing comparisons fail sample support. Effect directions are not proof of replication.')+theme(axis.text.x=element_text(angle=30,hjust=1))
ggsave(file.path(root,'figures','GSE120064_hypothesis_effects.png'),p,width=11,height=6,dpi=180)
cat('Sensitivity rows:',nrow(effects),'\n')
