options(stringsAsFactors=FALSE)
a<-grep('^--file=',commandArgs(),value=TRUE)
root<-if(!is.null(getOption('tac.expansion.root'))) getOption('tac.expansion.root') else if(length(a)) dirname(dirname(normalizePath(sub('^--file=','',a[1]),winslash='/'))) else normalizePath('.',winslash='/')
sourcefile<-file.path(root,'data','GSE262690_vandy_AS_full_processed.forDE.rds.gz')
dest<-file.path(root,'data','GSE262690_vandy_AS_full_processed.forDE.rds')
if(!file.exists(dest)) {
 stopifnot(file.exists(sourcefile))
 src<-gzfile(sourcefile,'rb');dst<-file(paste0(dest,'.partial'),'wb')
 repeat {bytes<-readBin(src,'raw',n=4*1024*1024);if(!length(bytes))break;writeBin(bytes,dst)}
 close(src);close(dst)
 if(!file.rename(paste0(dest,'.partial'),dest))stop('Could not finalize extracted human RDS')
}
stopifnot(file.info(dest)$size==966334993)
cat('Human inner compressed RDS is available.\n')
