from pathlib import Path
import csv
import openpyxl

root=Path(__file__).resolve().parents[1]
source=root/'data/41467_2025_62201_MOESM3_ESM.xlsx'
w=openpyxl.load_workbook(source,read_only=True,data_only=True)
rows=[]
for row in w['ST06'].values:
    ident,age,sex=row[:3]
    if not isinstance(age,(int,float)) or sex not in ('m','f'):continue
    individual=ident.replace(' ','') if ident.startswith('AS') else 'X'+ident.replace('-','_')
    rows.append(dict(individual=individual,Condition='AS' if ident.startswith('AS') else 'Control',age=age,sex=sex,
        source='https://doi.org/10.1038/s41467-025-62201-2; Supplementary Data 6, ST06',source_sample_id=ident))
assert len(rows)==20 and len(set(r['individual'] for r in rows))==20
with (root/'results/GSE262690_published_patient_covariates.csv').open('w',newline='',encoding='utf-8') as f:
    wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
print('Extracted 20 patients; preserved public source IDs and covariate provenance.')
