options(stringsAsFactors=FALSE,warn=1);Sys.setenv(TZ='UTC')
.libPaths(c('C:/Users/Mustafa Khaled/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages(library(data.table));suppressPackageStartupMessages(library(limma));suppressPackageStartupMessages(library(ggplot2))
a<-grep('^--file=',commandArgs(),value=TRUE);root<-if(!is.null(getOption('tac.expansion.root'))) getOption('tac.expansion.root') else if(length(a)) dirname(dirname(normalizePath(sub('^--file=','',a[1]),winslash='/'))) else normalizePath('.',winslash='/')
sink(file.path(root,'logs/12_lipidomics_3week.log'),split=TRUE)
out<-function(x,n)fwrite(x,file.path(root,'results',paste0('Lipidomics_',n,'.csv')))
z<-fread(file.path(root,'results/Lipidomics_source_abundance.csv'));samples<-c(paste0('sham',1:5),paste0('TAC',1:5))
x<-as.matrix(z[,..samples]);rownames(x)<-z$lipid
stopifnot(nrow(x)==799,ncol(x)==10,!anyDuplicated(rownames(x)),all(is.finite(x)),all(x>0))
md<-data.table(sample=samples,condition=factor(rep(c('Sham','TAC'),each=5),levels=c('Sham','TAC')))
out(md,'sample_design')
z[,explicit_20_4:=grepl('(^|[^0-9])20:4([^0-9]|$)',lipid)]
z[,named_epoxide_diol_hydroxylipid:=grepl('EET|DHET|HETE|EpOME|DiHOME|EpETE|DiHETE|EpDPE|DiHDPA',lipid,ignore.case=TRUE)]
out(z[,.(lipid,subclass,explicit_20_4,named_epoxide_diol_hydroxylipid)],'annotation_coverage')
# Primary analysis retains the deposited tissue-mass units; no global centering assumed.
lx<-log2(x);d<-model.matrix(~condition,md)
fit<-eBayes(lmFit(lx,d),trend=TRUE,robust=FALSE)
res<-as.data.table(topTable(fit,coef=2,number=Inf,sort.by='none'),keep.rownames='lipid');res<-merge(z[,.(lipid,subclass,explicit_20_4)],res,by='lipid',sort=FALSE)
res[,mean_Sham:=rowMeans(x[lipid,1:5,drop=FALSE])];res[,mean_TAC:=rowMeans(x[lipid,6:10,drop=FALSE])]
out(res,'allfeature_limma');out(res[explicit_20_4==TRUE],'explicit_20_4_results')
# Sensitivities: Welch tests on log abundance, and sample-median centering.
res[,Welch_P:=vapply(lipid,function(g)t.test(lx[g,6:10],lx[g,1:5])$p.value,numeric(1))];res[,Welch_FDR:=p.adjust(Welch_P,'BH')]
centered<-sweep(lx,2,apply(lx,2,median),'-');fc<-eBayes(lmFit(centered,d),trend=TRUE,robust=FALSE)
st<-as.data.table(topTable(fc,coef=2,n=Inf,sort.by='none'),keep.rownames='lipid')
sens<-merge(res[,.(lipid,subclass,explicit_20_4,primary_logFC=logFC,primary_FDR=adj.P.Val,Welch_P,Welch_FDR)],st[,.(lipid,median_centered_logFC=logFC,median_centered_FDR=adj.P.Val)],by='lipid');out(sens,'sensitivity')
qc<-copy(md);qc[,median_log2_abundance:=apply(lx,2,median)];qc[,source_feature_sum:=colSums(x)];qc[,positive_features:=colSums(x>0)];out(qc,'sample_QC')
# Summed deposited features are descriptive; they are not validated class totals.
long<-melt(z,id.vars=c('lipid','RT','subclass','explicit_20_4','named_epoxide_diol_hydroxylipid'),measure.vars=samples,variable.name='sample',value.name='source_abundance')
long<-merge(long,md,by='sample');out(long,'per_sample_abundance')
cs<-long[,.(summed_deposited_features=sum(source_abundance)),by=.(sample,condition,subclass)];out(cs,'class_feature_sums_descriptive')
# PCA is unsupervised; no classifier/PLS-DA or claimed prediction accuracy.
pc<-prcomp(t(lx),center=TRUE,scale.=TRUE);v<-100*pc$sdev^2/sum(pc$sdev^2);pp<-cbind(md,as.data.table(pc$x[,1:2]));out(pp,'PCA_scores')
pp[,label_y:=PC2+1.4];pp[sample%in%c('sham5','TAC2'),label_y:=PC2-1.4]
p<-ggplot(pp,aes(PC1,PC2,color=condition,label=sample))+geom_point(size=3)+geom_text(aes(y=label_y),size=3,show.legend=FALSE)+theme_bw(base_size=12)+labs(title='Three-week TAC lipidomics: unsupervised PCA',subtitle='799 deposited features; 5 samples per group; log2, feature-scaled',x=sprintf('PC1 (%.1f%%)',v[1]),y=sprintf('PC2 (%.1f%%)',v[2]))
ggsave(file.path(root,'figures/Lipidomics_PCA.png'),p,width=8,height=5,dpi=180)
priority<-c('FFA(20:4)','LPC(20:4)','LPE(20:4)','PC(16:0/20:4)','PE(16:0/20:4)','PE(18:0/20:4)')
stopifnot(all(priority%in%z$lipid));out(res[lipid%in%priority],'priority_results')
pl<-long[lipid%in%priority];pl[,plot_x:=as.numeric(condition)+seq(-.2,.2,length.out=.N),by=.(lipid,condition)]
p<-ggplot(pl,aes(plot_x,source_abundance,color=condition))+geom_point(size=2.5)+scale_x_continuous(breaks=1:2,labels=c('Sham','TAC'))+facet_wrap(~lipid,scales='free_y',ncol=3)+theme_bw(base_size=11)+theme(legend.position='none')+labs(x=NULL,y='Deposited abundance (source: ug/g)',title='Three-week lipid context: selected 20:4 annotations',subtitle='One point per deposited sample; statistical results corrected across all 799 features',caption='20:4 labels do not establish n-6 double-bond positions or enzyme origin.\nNo EET, DHET or HETE measurements are present in this workbook.')
ggsave(file.path(root,'figures/Lipidomics_20_4_Context.png'),p,width=10,height=7,dpi=180);ggsave(file.path(root,'figures/Lipidomics_20_4_Context.pdf'),p,width=10,height=7)
# Retain all samples in primary analysis; assess influence of each deposited sample.
loo<-rbindlist(lapply(seq_len(ncol(lx)),function(i){ff<-eBayes(lmFit(lx[,-i,drop=FALSE],d[-i,,drop=FALSE]),trend=TRUE,robust=FALSE);tt<-as.data.table(topTable(ff,coef=2,n=Inf,sort.by='none'),keep.rownames='lipid');tt[lipid%in%priority,.(lipid,omitted=samples[i],logFC,P.Value,adj.P.Val)]}))
out(loo,'priority_leave_one_out')
checks<-data.table(check=c('799_unique_features','10_samples_5_per_group','all_positive_finite','no_named_oxylipins','all799_FDR_family'),passed=c(nrow(z)==799&&!anyDuplicated(z$lipid),nrow(md)==10&&all(table(md$condition)==5),all(is.finite(x)&x>0),!any(z$named_epoxide_diol_hydroxylipid),nrow(res)==799))
stopifnot(all(checks$passed));out(checks,'integrity_checks');print(res[lipid%in%priority]);print(res[,.(features=.N,significant=sum(adj.P.Val<.05),up=sum(adj.P.Val<.05&logFC>0),down=sum(adj.P.Val<.05&logFC<0))]);print(qc);print(sessionInfo());sink()
