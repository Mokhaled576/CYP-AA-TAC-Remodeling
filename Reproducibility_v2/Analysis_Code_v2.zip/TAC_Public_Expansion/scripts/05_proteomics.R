options(stringsAsFactors=FALSE,warn=1);Sys.setenv(TZ='UTC')
.libPaths(c('C:/Users/Mustafa Khaled/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages(library(data.table));suppressPackageStartupMessages(library(limma));suppressPackageStartupMessages(library(ggplot2))
a<-grep('^--file=',commandArgs(),value=TRUE);root<-if(!is.null(getOption('tac.expansion.root'))) getOption('tac.expansion.root') else if(length(a)) dirname(dirname(normalizePath(sub('^--file=','',a[1]),winslash='/'))) else normalizePath('.',winslash='/')
sink(file.path(root,'logs','05_proteomics.log'),split=TRUE)
out<-function(x,n)fwrite(x,file.path(root,'results',paste0(n,'.csv')))
z<-fread(file.path(root,'data','fractionated_FP_TMT16_protein.tsv'))
md<-fread(file.path(root,'data','P3464_metadata.csv'))[sample=='input' & file=='fractionated_FP_TMT16_protein.tsv']
stopifnot(nrow(md)==16,!anyDuplicated(md$col.name),all(md$col.name%in%names(z)))
out(md,'PXD061784_input_channel_design')
# Use actual condition labels to compare time-matched controls. Do not use ctrl or ctrl.ID:
# these source metadata fields label even 7d samples against Sham_1d.
channels<-md$col.name;m<-as.matrix(z[,..channels])
eligible<-z$Organism=='Mus musculus' & !grepl('contam|rev_|DECOY',z$Protein,ignore.case=TRUE) & z[['Unique Peptides']]>=2 & rowSums(is.finite(m)&m>0)==16
z[,analysis_eligible:=eligible]
panel<-fread(file.path(root,'results','frozen_mouse_gene_panel.csv'))$mouse_gene
cov<-data.table(gene=panel,feature_present=panel%in%z$Gene,eligible_unique2_all16=panel%in%z[eligible]$Gene)
out(cov,'PXD061784_panel_coverage')
out(z[Gene%in%panel],'PXD061784_panel_protein_records')
zfit<-z[eligible];x<-log2(m[eligible,,drop=FALSE]);rownames(x)<-zfit$Protein
offset<-apply(x,2,median);xn<-sweep(x,2,offset,'-')+median(offset)
md[,condition:=factor(condition,levels=c('Sham_1d','TAC_1d','Sham_7d','TAC_7d'))]
design<-model.matrix(~0+condition,md);colnames(design)<-levels(md$condition)
fit<-lmFit(xn,design);ct<-makeContrasts(TAC_1d_vs_Sham_1d=TAC_1d-Sham_1d,TAC_7d_vs_Sham_7d=TAC_7d-Sham_7d,levels=design)
fit<-eBayes(contrasts.fit(fit,ct),trend=TRUE,robust=FALSE)
res<-rbindlist(lapply(seq_len(ncol(ct)),function(i){t<-as.data.table(topTable(fit,coef=i,number=Inf,sort.by='none'),keep.rownames='Protein');t[,contrast:=colnames(ct)[i]];t}))
res<-merge(res,zfit[,.(Protein,Gene,`Unique Peptides`,Coverage)],by='Protein',sort=FALSE)
res[,FDR_global:=p.adjust(P.Value,'BH')];out(res,'PXD061784_allprotein_DE_exploratory');out(res[Gene%in%panel],'PXD061784_panel_DE_exploratory')
out(data.table(channel=channels,median_log2_raw=offset,center_offset=offset-median(offset)),'PXD061784_channel_normalization')
# Raw-channel effect is a normalization sensitivity check, not a second validation cohort.
sel<-which(zfit$Gene%in%panel)
long<-rbindlist(lapply(sel,function(i)data.table(Protein=zfit$Protein[i],gene=zfit$Gene[i],channel=channels,log2_raw=x[i,],log2_median_centered=xn[i,])))
long<-merge(long,md[,.(channel=col.name,condition,rep)],by='channel',sort=FALSE)
out(long,'PXD061784_panel_per_channel')
sensitivity<-long[,.(effect_normalized=mean(log2_median_centered[condition==paste0('TAC_',d)])-mean(log2_median_centered[condition==paste0('Sham_',d)]),effect_raw=mean(log2_raw[condition==paste0('TAC_',d)])-mean(log2_raw[condition==paste0('Sham_',d)])),by=.(gene,Protein,d=sub('.*_','',condition))]
out(sensitivity,'PXD061784_normalization_sensitivity')
p<-ggplot(long[gene%in%c('Ephx2','Ephx1','Cyp2d22','Cyp27a1')],aes(condition,log2_median_centered))+geom_point(size=2,color='#6B4A8A')+facet_wrap(~gene,scales='free_y')+theme_bw(base_size=11)+labs(x='Condition',y='Median-centered log2 reporter intensity',caption='Four channels per condition; time-matched Sham controls. Early TAC protein abundance does not establish late-stage activity.')+theme(axis.text.x=element_text(angle=30,hjust=1))
ggsave(file.path(root,'figures','PXD061784_detected_proteins.png'),p,width=10,height=7,dpi=180)
ggsave(file.path(root,'figures','PXD061784_detected_proteins.pdf'),p,width=10,height=7)
cat('Input records:',nrow(z),'eligible:',sum(eligible),'frozen panel detected:',sum(cov$feature_present),'eligible:',sum(cov$eligible_unique2_all16),'\n')
cat('Matched-time comparisons complete; source ctrl fields not used. No replicate pairing assumed.\n');sink()
