options(stringsAsFactors=FALSE)
Sys.setenv(TZ='UTC')
.libPaths(c('C:/Users/Mustafa Khaled/AppData/Local/R/win-library/4.5', .libPaths()))
suppressPackageStartupMessages(library(data.table))
arg <- grep('^--file=',commandArgs(),value=TRUE)
root <- dirname(dirname(normalizePath(sub('^--file=','',arg[1]),winslash='/')))
previous <- file.path(dirname(root),'Supporting_Analyses','tables')
dir.create(file.path(root,'results'),showWarnings=FALSE)
# Freeze existing discovery features and hypotheses before new expression data are inspected.
detect <- fread(file.path(previous,'02_broad_CYP_detectability_discovery.csv'))
genes <- sort(unique(detect$gene))
fwrite(data.table(mouse_gene=genes,source='Existing broad detectability panel; inherited, not newly selected'),file.path(root,'results','frozen_mouse_gene_panel.csv'))
hyp <- data.table(cell_type=c('Endothelial','Endothelial','Macrophage','Fibroblast','Cardiomyocyte'),
 gene=c('Ephx2','Cyp1b1','Cyp4f18','Cyp1b1','Ephx2'),
 discovery_question=c('Reduced endothelial expression/detection during remodeling','Reduced endothelial expression/detection during remodeling','Increased macrophage expression during remodeling','Increased fibroblast expression during remodeling','Exploratory: cardiomyocyte expression and potential contribution to spatial discordance'),
 role=c(rep('Existing finding to validate',4),'Exploratory; no assumed direction'),
 primary_new_dataset=c(rep('GSE120064',4),'GSE95140'))
fwrite(hyp,file.path(root,'results','frozen_validation_questions.csv'))
samples <- data.table(GSM=paste0('GSM',3392798:3392813),
 individual_label=c('0w_1','0w_2','11w_1','11w_2','2w_1','2w_2',paste0('5w_',1:7),paste0('8w_',1:3)))
samples[,week:=as.integer(sub('w_.*','',individual_label))]
samples[,source:=paste0('https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=',GSM)]
samples[,verification:='Series sample title; cross-check expression columns and individual metadata before aggregation']
fwrite(samples,file.path(root,'results','GSE120064_expected_sample_roster.csv'))
external <- fread(file.path(previous,'05_external_headline_summary.csv'))
external <- external[cell_type=='ALL']
fwrite(external,file.path(root,'results','existing_external_results_for_comparison.csv'))
writeLines(c('Preparation only: no new dataset expression results.',
 paste('Frozen mouse panel size:',length(genes)),
 paste('GSE120064 roster size:',nrow(samples)),
 'Expected labels: baseline 2; two weeks 2; five weeks 7; eight weeks 3; eleven weeks 2.',
 'These are expected individual labels, not verified retained sample sizes.',
 'GSE120064 and GSE133054 share the same source publication; do not assume independent cohorts.',
 'GSE95140 is a subseries of GSE95143; do not count them as independent datasets.',
 'No estrogen hypotheses included.'),file.path(root,'results','preparation_audit.txt'))
cat('Prepared comparison files. No new expression analysis performed.\n')
