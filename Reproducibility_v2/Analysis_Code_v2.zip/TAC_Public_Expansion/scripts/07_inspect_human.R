options(stringsAsFactors=FALSE,warn=1);Sys.setenv(TZ='UTC')
.libPaths(c('C:/Users/Mustafa Khaled/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages(library(SeuratObject));suppressPackageStartupMessages(library(Matrix));suppressPackageStartupMessages(library(data.table))
a<-grep('^--file=',commandArgs(),value=TRUE);root<-if(!is.null(getOption('tac.expansion.root'))) getOption('tac.expansion.root') else if(length(a)) dirname(dirname(normalizePath(sub('^--file=','',a[1]),winslash='/'))) else normalizePath('.',winslash='/')
sink(file.path(root,'logs','07_human_object_inspection.txt'),split=TRUE)
o<-readRDS(file.path(root,'data','GSE262690_vandy_AS_full_processed.forDE.rds'))
cat('Object class:',class(o),'\n');cat('Slots:',slotNames(o),'\n')
if(inherits(o,'Seurat')) {
 cat('Dimensions:',dim(o),'\nAssays:',names(o@assays),'\n')
 md<-o@meta.data
 cat('Metadata columns:',names(md),'\n')
 for(n in names(md)){if(length(unique(md[[n]]))<100) {cat('\n',n,'\n');print(table(md[[n]],useNA='ifany'))}}
 for(n in names(o@assays)){cat('Assay',n,'class:',class(o@assays[[n]]),'slots:',slotNames(o@assays[[n]]),'\n')}
 fwrite(data.table(cell=rownames(md),md),file.path(root,'results','GSE262690_cell_metadata.csv'))
 saveRDS(list(class=class(o),metadata_fields=names(md),assays=names(o@assays)),file.path(root,'logs','GSE262690_structure.rds'))
}
sink()
