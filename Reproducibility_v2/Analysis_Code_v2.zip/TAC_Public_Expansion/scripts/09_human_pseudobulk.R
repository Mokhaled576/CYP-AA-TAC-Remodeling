options(stringsAsFactors=FALSE,warn=1);Sys.setenv(TZ='UTC',OMP_NUM_THREADS=2,OPENBLAS_NUM_THREADS=2)
.libPaths(c('C:/Users/Mustafa Khaled/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages(library(SeuratObject));suppressPackageStartupMessages(library(Matrix));suppressPackageStartupMessages(library(data.table));suppressPackageStartupMessages(library(edgeR));suppressPackageStartupMessages(library(ggplot2));setDTthreads(2)
a<-grep('^--file=',commandArgs(),value=TRUE);root<-if(!is.null(getOption('tac.expansion.root'))) getOption('tac.expansion.root') else if(length(a)) dirname(dirname(normalizePath(sub('^--file=','',a[1]),winslash='/'))) else normalizePath('.',winslash='/')
sink(file.path(root,'logs','09_human_pseudobulk.log'),split=TRUE)
out<-function(x,n)fwrite(x,file.path(root,'results',paste0(n,'.csv')))
clinical<-fread(file.path(root,'results','GSE262690_published_patient_covariates.csv'))
cache<-file.path(root,'logs','GSE262690_pseudobulk_cache.rds')
if(file.exists(cache)){o<-readRDS(cache);pb<-o$counts;groups<-o$groups;detect<-o$detection;panel<-o$panel;rm(o)} else {
 o<-readRDS(file.path(root,'data','GSE262690_vandy_AS_full_processed.forDE.rds'))
 m<-o@assays$RNA@counts;md<-as.data.table(o@meta.data,keep.rownames='cell')
 stopifnot(identical(colnames(m),md$cell),all(is.finite(m@x)),all(m@x>=0),all(m@x==floor(m@x)))
 stopifnot(setequal(unique(md$orig.ident),clinical$individual))
 md[,individual:=orig.ident];md[,CellType:=as.character(seurat_cell_type)]
 md[,group_id:=paste(individual,CellType,sep='__')]
 groups<-md[,.(n_cells=.N,median_UMI=median(nCount_RNA),median_genes=median(nFeature_RNA),median_mito_pct=median(pct_counts_mt)),by=.(group_id,individual,CellType,Condition)]
 groups<-merge(groups,clinical[,.(individual,age,sex)],by='individual',sort=FALSE)
 inc<-sparseMatrix(i=seq_len(ncol(m)),j=match(md$group_id,groups$group_id),x=1,dims=c(ncol(m),nrow(groups)))
 pb<-as.matrix(m%*%inc);colnames(pb)<-groups$group_id
 panel<-sort(unique(c(grep('^CYP',rownames(m),value=TRUE),'EPHX1','EPHX2','POR','CYB5A','CYB5B','PLA2G4A','PTGS1','PTGS2','ALOX5','ALOX12','ALOX15','LTA4H','LTC4S','PTGIS','TBXAS1')))
 present<-intersect(panel,rownames(m));v<-m[present,,drop=FALSE]
 pos<-as.matrix((v>0)%*%inc)
 detect<-rbindlist(lapply(seq_len(nrow(groups)),function(j)data.table(group_id=groups$group_id[j],gene=present,positive=pos[,j],detection_pct=100*pos[,j]/groups$n_cells[j])))
 saveRDS(list(counts=pb,groups=groups,detection=detect,panel=panel),cache)
 rm(o,m,md,v,inc,pos);gc()
}
stopifnot(all(groups$Condition==clinical$Condition[match(groups$individual,clinical$individual)]))
out(groups,'GSE262690_patient_celltype_QC');out(merge(detect,groups,by='group_id',sort=FALSE),'GSE262690_panel_patient_detection')
out(data.table(gene=panel,feature_present=panel%in%rownames(pb)),'GSE262690_panel_coverage')
out(data.table(gene=rownames(pb),pb),'GSE262690_allgene_patient_pseudobulk_counts')
out(clinical[,.(n_patients=.N,median_age=median(age),min_age=min(age),max_age=max(age),male=sum(sex=='m'),female=sum(sex=='f')),by=Condition],'GSE262690_demographic_summary')
results<-list();cpmlist<-list();diagnostics<-list()
for(ct in unique(groups$CellType)) {
 g<-copy(groups[CellType==ct & n_cells>=30]);g[,Condition:=factor(Condition,levels=c('Control','AS'))];g[,sex:=factor(sex)]
 if(any(table(g$Condition)<5))next
 cnt<-pb[!grepl('^MT-',rownames(pb)),g$group_id,drop=FALSE]
 for(model in c('unadjusted','age_sex_adjusted','age_sex_exclude_AS9')) {
   gg<-if(model=='age_sex_exclude_AS9')g[individual!='AS9'] else g
   gg[,age_centered:=age-mean(age)]
   design<-if(model=='unadjusted')model.matrix(~Condition,gg) else model.matrix(~age_centered+sex+Condition,gg)
   diagnostics[[paste(ct,model)]]<-data.table(CellType=ct,model=model,n_control=sum(gg$Condition=='Control'),n_AS=sum(gg$Condition=='AS'),design_rank=qr(design)$rank,design_columns=ncol(design),condition_number=kappa(design))
   if(qr(design)$rank<ncol(design))next
   y<-DGEList(cnt[,gg$group_id,drop=FALSE]);keep<-filterByExpr(y,design=design)
   y<-calcNormFactors(y[keep,,keep.lib.sizes=FALSE],method='TMM');y<-estimateDisp(y,design);fit<-glmQLFit(y,design,robust=FALSE)
   tt<-as.data.table(topTags(glmQLFTest(fit,coef=which(colnames(design)=='ConditionAS')),n=Inf,sort.by='none')$table,keep.rownames='gene')
   tt[,`:=`(CellType=ct,model=model,n_control=sum(gg$Condition=='Control'),n_AS=sum(gg$Condition=='AS'),panel_gene=gene%in%panel)]
   results[[paste(ct,model)]]<-tt
   if(model=='age_sex_adjusted'){
     ix<-which(rownames(cnt)%in%panel);eff<-y$samples$lib.size*y$samples$norm.factors
     cc<-sweep(cnt[ix,gg$group_id,drop=FALSE],2,eff,'/')*1e6
     cpmlist[[ct]]<-data.table(gene=rep(rownames(cc),times=nrow(gg)),group_id=rep(gg$group_id,each=nrow(cc)),TMM_CPM=as.vector(cc))
   }
   cat(ct,model,'complete; tested genes:',nrow(tt),'\n')
 }
}
de<-rbindlist(results);de[,FDR_global_by_model:=p.adjust(PValue,'BH'),by=model]
out(de,'GSE262690_allgene_DE_exploratory');out(de[panel_gene==TRUE],'GSE262690_panel_DE_exploratory')
out(rbindlist(diagnostics),'GSE262690_design_diagnostics')
cp<-merge(rbindlist(cpmlist),groups,by='group_id',sort=FALSE);out(cp,'GSE262690_panel_patient_TMM_CPM')
priority<-c('EPHX2','CYP1B1','CYP2J2','CYP4A11','CYP4F2','CYP4F3')
p<-ggplot(cp[gene%in%priority & CellType%in%c('Cardiomyocyte','Endothelial','Fibroblast','Macrophage')],aes(Condition,log2(TMM_CPM+1)))+geom_point(aes(color=age),position=position_jitter(width=.12,height=0),size=1.6)+facet_grid(gene~CellType,scales='free_y')+scale_color_gradient(low='#3182BD',high='#B33D30')+theme_bw(base_size=10)+labs(x='Patient group',y='Patient pseudobulk log2(TMM CPM + 1)',caption='One point per patient/cell type, >=30 nuclei. Colors: age. Plots show abundance; disease estimates require covariate models and remain observational.')
ggsave(file.path(root,'figures','GSE262690_patient_expression.png'),p,width=12,height=12,dpi=180)
ggsave(file.path(root,'figures','GSE262690_patient_expression.pdf'),p,width=12,height=12)
capture.output(sessionInfo(),file=file.path(root,'logs','09_R_session.txt'))
cat('Human analysis complete. Age adjustment cannot remove all donor/clinical/technical confounding.\n');sink()
