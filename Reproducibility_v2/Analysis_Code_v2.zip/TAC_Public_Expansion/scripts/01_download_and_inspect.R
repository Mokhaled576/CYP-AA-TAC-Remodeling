options(stringsAsFactors=FALSE, timeout=300)
Sys.setenv(TZ='UTC')
.libPaths(c('C:/Users/Mustafa Khaled/AppData/Local/R/win-library/4.5', .libPaths()))
suppressPackageStartupMessages(library(data.table))
arg <- grep('^--file=', commandArgs(), value=TRUE)
root <- dirname(dirname(normalizePath(sub('^--file=', '', arg[1]), winslash='/')))
for (d in c('data','logs','results')) dir.create(file.path(root,d),recursive=TRUE,showWarnings=FALSE)
sink(file.path(root,'logs','download_inspection.log'),split=TRUE)
cat('Started:',format(Sys.time(),tz='UTC'), 'UTC\n')
items <- data.table(
 accession=c('GSE95140','GSE120064','GSE120064','GSE262690'),
 filename=c('GSE95140_single-cardiomyocyte_RNA-seq.txt.gz','GSE120064_TAC_raw_umi_matrix.csv.gz','GSE120064_TAC_clean_cell_info_summary.txt.gz','GSE262690_vandy_AS_full_processed.forDE.rds.gz'),
 group=c('GSE95nnn','GSE120nnn','GSE120nnn','GSE262nnn'))
items[, url:=paste0('https://ftp.ncbi.nlm.nih.gov/geo/series/',group,'/',accession,'/suppl/',filename)]
metadata <- unique(items[,.(accession,group)])
metadata[,filename:=paste0(accession,'_family.soft.gz')]
metadata[,url:=paste0('https://ftp.ncbi.nlm.nih.gov/geo/series/',group,'/',accession,'/soft/',filename)]
jobs <- rbindlist(list(metadata,items),use.names=TRUE)
jobs[, `:=`(status='',bytes=0,error='')]
for(i in seq_len(nrow(jobs))) {
 dest <- file.path(root,'data',jobs$filename[i])
 cat('\n',jobs$filename[i],'\n')
 if(file.exists(dest) && file.info(dest)$size>0) {
   jobs$status[i] <- 'existing_unverified'
 } else {
   err <- tryCatch({download.file(jobs$url[i],dest,mode='wb',method='libcurl',quiet=FALSE);NULL},error=function(e)conditionMessage(e))
   if(!is.null(err)) {jobs$status[i]<-'download_failed';jobs$error[i]<-err;next}
   jobs$status[i]<-'downloaded'
 }
 jobs$bytes[i]<-file.info(dest)$size
 # Fully read gzip streams before trusting downloaded content.
 ok <- tryCatch({con<-gzfile(dest,'rb');repeat {b<-readBin(con,'raw',n=1048576);if(!length(b))break};close(con);TRUE},error=function(e){jobs$error[i]<<-conditionMessage(e);FALSE})
 if(!ok) {jobs$status[i]<-'validation_failed';next}
 jobs$status[i]<-'gzip_readable'
 if(grepl('soft.gz$',dest)) {
   lines<-readLines(gzfile(dest),warn=FALSE)
   keep<-grepl('^\\^SAMPLE|^!Sample_(title|source_name|characteristics|description|data_processing|treatment_protocol|growth_protocol)',lines)
   writeLines(lines[keep],file.path(root,'results',paste0(jobs$accession[i],'_sample_metadata.txt')))
 } else if(grepl('rds.gz$',dest)) {
   cat('Human object downloaded. Inspect class, assays and patient fields before analysis.\n')
 } else {
   preview<-readLines(gzfile(dest),n=5,warn=FALSE)
   writeLines(preview,file.path(root,'results',paste0(jobs$filename[i],'.preview.txt')))
 }
}
fwrite(jobs,file.path(root,'results','download_status.csv'))
capture.output(sessionInfo(),file=file.path(root,'logs','R_session.txt'))
cat('\nVerified readable files:',sum(jobs$status=='gzip_readable'),'of',nrow(jobs),'\n')
cat('No inferential analyses are run before sample identities and expression units are checked.\n')
sink()
if(any(jobs$status!='gzip_readable')) quit(status=2)
