from pathlib import Path
import openpyxl,csv,json,re,collections,math
r=Path(__file__).resolve().parents[1];p=r/'data/TOTAL-ori.xlsx';w=openpyxl.load_workbook(p,read_only=True,data_only=True);rows=list(w.active.values)
h=rows[0];assert len(rows)==800;assert list(h[3:])==['sham1','sham2','sham3','sham4','sham5','TAC1','TAC2','TAC3','TAC4','TAC5']
with (r/'results/Lipidomics_source_abundance.csv').open('w',newline='',encoding='utf-8') as f:
 wr=csv.writer(f);wr.writerow(['lipid','RT','subclass']+list(h[3:]));wr.writerows(rows[1:])
labels=[str(x[0]) for x in rows[1:]];vals=[x for row in rows[1:] for x in row[3:]]
audit={'rows':len(labels),'unique_lipid_names':len(set(labels)),'classes':dict(collections.Counter(x[2] for x in rows[1:])),'missing':sum(x is None for x in vals),'zeros':sum(x==0 for x in vals),'negative':sum(isinstance(x,(int,float)) and x<0 for x in vals),'min_positive':min(x for x in vals if isinstance(x,(int,float)) and x>0),'explicit_20_4_species':[x for x in labels if re.search(r'(?<!\d)20:4(?!\d)',x)],'oxylipin_label_matches':[x for x in labels if re.search(r'EET|DHET|HETE|EpOME|DiHOME|EpETE|DiHETE|EpDPE|DiHDPA|arachidon|eicosatrien|eicosatetraen',x,re.I)],'source_units':h[0],'checksum':'038c56353fe3f17e7844f1430067598c3b7db0758d8c89b132951e7f48d4e7ba','source_doi':'10.17632/bfry768hk7.1','sample_linkage':'Five sample columns per group; paper Fig1 reports five mice/group. Same contributor/time/model/799 features support likely linkage but repository does not explicitly link paper DOI.','analytical_QC':'No raw spectra, blank/QC injections, run order, internal-standard recoveries, limits of detection or sample-specific clinical covariates supplied.'}
(r/'logs/Lipidomics_input_audit.json').write_text(json.dumps(audit,indent=2,ensure_ascii=True))
print(json.dumps(audit,indent=2,ensure_ascii=True))
