options(stringsAsFactors=FALSE,warn=1);Sys.setenv(TZ='UTC')
.libPaths(c('C:/Users/Mustafa Khaled/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages(library(data.table));suppressPackageStartupMessages(library(edgeR));suppressPackageStartupMessages(library(ggplot2))
a<-grep('^--file=',commandArgs(),value=TRUE);root<-if(!is.null(getOption('tac.expansion.root'))) getOption('tac.expansion.root') else if(length(a)) dirname(dirname(normalizePath(sub('^--file=','',a[1]),winslash='/'))) else normalizePath('.',winslash='/')
sink(file.path(root,'logs/11_endothelial_4week.log'),split=TRUE)
out<-function(x,n)fwrite(x,file.path(root,'results',paste0('GSE296709_',n,'.csv')))
z<-fread(file.path(root,'results/GSE296709_source_counts.csv'));md<-fread(file.path(root,'results/GSE296709_sample_design.csv'))
stopifnot(!anyDuplicated(z$Geneid),nrow(md)==15,all(md$sample%in%names(z)))
cols<-md$sample;m<-as.matrix(z[,..cols])
stopifnot(all(is.finite(m)),all(m>=0),all(m==round(m)))
rownames(m)<-z$Geneid;colnames(m)<-md$sample
wt<-md[source_genotype=='WT'];wt[,condition:=factor(condition,levels=c('Sham','TAC'))]
stopifnot(sum(wt$condition=='Sham')==3,sum(wt$condition=='TAC')==5)
x<-m[,wt$sample,drop=FALSE]
# Identify mitochondria by genomic chromosome, not gene symbol alone.
nuclear<-!grepl('(^|;)chrM(;|$)',z$Chr)&!grepl('^mt-',z$Geneid,ignore.case=TRUE)
qc<-copy(md);qc[,library_counts:=colSums(m)];qc[,genes_nonzero:=colSums(m>0)];qc[,mitochondrial_fraction:=colSums(m[!nuclear,,drop=FALSE])/colSums(m)]
out(qc,'sample_QC')
panel<-fread(file.path(root,'results/frozen_mouse_gene_panel.csv'))$mouse_gene
fitDE<-function(mat,metadata){
 d<-model.matrix(~condition,metadata);stopifnot(qr(d)$rank==ncol(d))
 y<-DGEList(mat);k<-filterByExpr(y,design=d);y<-y[k,,keep.lib.sizes=FALSE];y<-calcNormFactors(y)
 y<-estimateDisp(y,d);f<-glmQLFit(y,d,robust=FALSE);t<-glmQLFTest(f,coef=2)
 tab<-as.data.table(topTags(t,n=Inf,sort.by='none')$table,keep.rownames='gene')
 list(table=tab,y=y,design=d)
}
f<-fitDE(x[nuclear,,drop=FALSE],wt);out(f$table,'WT_allgene_DE');out(f$table[gene%in%panel],'WT_panel_DE')
cov<-data.table(gene=panel,feature_present=panel%in%rownames(x),expression_eligible=panel%in%f$table$gene)
out(cov,'panel_coverage')
fa<-fitDE(x,wt);sens<-merge(f$table[,.(gene,nuclear_logFC=logFC,nuclear_FDR=FDR)],fa$table[,.(gene,allgene_logFC=logFC,allgene_FDR=FDR)],by='gene',all=TRUE)
out(sens[gene%in%panel],'normalization_sensitivity')
loo<-rbindlist(lapply(seq_len(nrow(wt)),function(i){v<-fitDE(x[nuclear,-i,drop=FALSE],wt[-i]);v$table[gene%in%c('Ephx2','Cyp1b1'),.(gene,omitted=wt$sample[i],logFC,PValue,FDR)]}))
out(loo,'priority_leave_one_out')
# Display all deposited target genes, including genes ineligible for DE.
display<-DGEList(x,lib.size=f$y$samples$lib.size);display$samples$norm.factors<-f$y$samples$norm.factors
cp<-cpm(display,log=FALSE);lp<-cpm(display,log=TRUE,prior.count=2)
markers<-c('Ephx2','Cyp1b1','Cdh5','Pecam1','Kdr','Ptprc','Col1a1','Tnnt2')
lng<-rbindlist(lapply(intersect(markers,rownames(cp)),function(g)data.table(gene=g,sample=colnames(cp),TMM_CPM=cp[g,],logCPM=lp[g,])))
lng<-merge(lng,wt,by='sample');out(lng,'priority_and_marker_expression')
lng[,plot_x:=as.numeric(condition)+seq(-.2,.2,length.out=.N),by=.(gene,condition)]
p<-ggplot(lng[gene%in%c('Ephx2','Cyp1b1')],aes(plot_x,logCPM,color=condition))+geom_point(size=3)+geom_text(aes(label=sample_id),vjust=-.7,size=3)+scale_x_continuous(breaks=1:2,labels=c('Sham','TAC'))+facet_wrap(~gene,scales='free_y')+theme_bw(base_size=12)+theme(legend.position='none')+labs(x=NULL,y='TMM log2 CPM (prior count 2)',title='Independent four-week sorted endothelial RNA-seq',subtitle='GSE296709: source WT-labeled controls; 3 Sham, 5 TAC',caption='All samples retained; primary inference uses edgeR QL and all-gene BH FDR.\nEphx2 fails the primary expression filter; displayed values are descriptive.
Bulk sorted endothelial RNA does not resolve subtypes or spatial origin.')
ggsave(file.path(root,'figures/GSE296709_Endothelial_4week.png'),p,width=9,height=5,dpi=180);ggsave(file.path(root,'figures/GSE296709_Endothelial_4week.pdf'),p,width=9,height=5)
pdf(file.path(root,'figures/GSE296709_MDS.pdf'),width=7,height=6);plotMDS(f$y,labels=wt$sample_id,col=ifelse(wt$condition=='TAC','firebrick','steelblue'));dev.off()
print(f$table[gene%in%c('Ephx2','Cyp1b1')]);print(qc[source_genotype=='WT']);print(loo)
cat('Tested nuclear genes:',nrow(f$table),'\n');print(sessionInfo());sink()
