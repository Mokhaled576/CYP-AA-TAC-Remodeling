options(stringsAsFactors=FALSE,warn=1)
Sys.setenv(TZ='UTC',OMP_NUM_THREADS=2,OPENBLAS_NUM_THREADS=2)
.libPaths(c('C:/Users/Mustafa Khaled/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages(library(data.table));suppressPackageStartupMessages(library(ggplot2))
setDTthreads(2)
a<-grep('^--file=',commandArgs(),value=TRUE);root<-if(!is.null(getOption('tac.expansion.root'))) getOption('tac.expansion.root') else if(length(a)) dirname(dirname(normalizePath(sub('^--file=','',a[1]),winslash='/'))) else normalizePath('.',winslash='/')
sink(file.path(root,'logs','04_cardiomyocyte_timecourse.log'),split=TRUE)
out<-function(x,n)fwrite(x,file.path(root,'results',paste0(n,'.csv')))
panel<-fread(file.path(root,'results','frozen_mouse_gene_panel.csv'))$mouse_gene
z<-fread(text=paste(readLines(gzfile(file.path(root,'data','GSE95140_single-cardiomyocyte_RNA-seq.txt.gz')),warn=FALSE),collapse='\n'))
genes<-z[[1]];z[[1]]<-NULL;m<-as.matrix(z);rownames(m)<-genes
stopifnot(!anyDuplicated(genes),all(is.finite(m)),all(m>=0))
cells<-grep('^(Sham_[12]|TAC_(D3|W[1248])_[12])_[0-9]+$',colnames(m),value=TRUE)
meta<-data.table(cell=cells,individual=sub('_[0-9]+$','',cells))
meta[,condition:=sub('_[12]$','',individual)]
meta[,condition:=factor(condition,levels=c('Sham','TAC_D3','TAC_W1','TAC_W2','TAC_W4','TAC_W8'))]
meta[,features_RPKM_gt_point1:=colSums(m[,cell,drop=FALSE]>.1)]
meta[,retained_original_threshold:=features_RPKM_gt_point1>5000]
out(meta,'GSE95140_cell_QC')
out(meta[,.(n_input=.N,n_retained=sum(retained_original_threshold),median_features=median(features_RPKM_gt_point1)),by=.(individual,condition)],'GSE95140_individual_QC')
out(data.table(gene=panel,feature_present=panel%in%genes),'GSE95140_panel_coverage')
ix<-which(genes%in%panel);v<-m[ix,cells,drop=FALSE]
summarize<-function(qc){
 use<-if(qc=='published_threshold')meta[retained_original_threshold==TRUE] else meta
 ans<-rbindlist(lapply(unique(use$individual),function(id){
   cc<-use[individual==id]$cell;vv<-v[,cc,drop=FALSE]
   data.table(individual=id,condition=as.character(use[individual==id]$condition[1]),gene=rownames(vv),n_cells=length(cc),mean_RPKM=rowMeans(vv),mean_log2RPKM1=rowMeans(log2(vv+1)),detection_RPKM_gt_point1=rowMeans(vv>.1)*100)
 }))
 ans[,strategy:=qc];ans
}
per<-rbind(summarize('published_threshold'),summarize('all_deposited_cells'))
out(per,'GSE95140_panel_individual_expression')
effects<-rbindlist(lapply(split(per,by=c('strategy','gene'),keep.by=TRUE),function(x){
 base<-x[condition=='Sham'];if(nrow(base)<2)return(NULL)
 rbindlist(lapply(setdiff(unique(x$condition),'Sham'),function(co){
   tx<-x[condition==co];if(nrow(tx)<2)return(NULL)
   dif<-as.vector(outer(tx$mean_RPKM,base$mean_RPKM,'-'))
   data.table(strategy=x$strategy[1],gene=x$gene[1],contrast=paste0(co,'_vs_Sham'),n_baseline=nrow(base),n_TAC=nrow(tx),mean_baseline_RPKM=mean(base$mean_RPKM),mean_TAC_RPKM=mean(tx$mean_RPKM),
   log2FC_pc_point1=log2((mean(tx$mean_RPKM)+.1)/(mean(base$mean_RPKM)+.1)),log2FC_pc1=log2((mean(tx$mean_RPKM)+1)/(mean(base$mean_RPKM)+1)),
   difference_mean_log2RPKM1=mean(tx$mean_log2RPKM1)-mean(base$mean_log2RPKM1),detection_change_percentage_points=mean(tx$detection_RPKM_gt_point1)-mean(base$detection_RPKM_gt_point1),all_crosspairs_same_direction=all(dif>0)||all(dif<0),
   status=if(all(dif>0))'Both TAC individuals above both Sham individuals' else if(all(dif<0))'Both TAC individuals below both Sham individuals' else 'Overlapping individual ranges')
 }))
}))
out(effects,'GSE95140_individual_effects_descriptive')
bulkcols<-grep('^(Sham_[12]|TAC_(D3|W[1248])_[12])_Bulk$',colnames(m),value=TRUE)
out(data.table(gene=genes[ix],m[ix,bulkcols,drop=FALSE]),'GSE95140_deposited_bulk_RPKM_separate')
per[,condition:=factor(condition,levels=c('Sham','TAC_D3','TAC_W1','TAC_W2','TAC_W4','TAC_W8'))]
p<-ggplot(per[strategy=='published_threshold' & gene%in%c('Ephx2','Cyp2j6','Cyp2j9','Cyp1b1')],aes(condition,log2(mean_RPKM+1),group=gene))+geom_point(size=2,color='#216B8A')+facet_wrap(~gene,scales='free_y')+theme_bw(base_size=11)+labs(x='Condition',y='Individual mean expression: log2(RPKM + 1)',caption='Two individual labels per condition. Published >5000 genes at RPKM >0.1 threshold. Descriptive effects; no cell-level P values.')+theme(axis.text.x=element_text(angle=30,hjust=1))
ggsave(file.path(root,'figures','GSE95140_cardiomyocyte_individuals.png'),p,width=10,height=7,dpi=180)
ggsave(file.path(root,'figures','GSE95140_cardiomyocyte_individuals.pdf'),p,width=10,height=7)
cat('Genes:',nrow(m),'single cells:',nrow(meta),'retained:',sum(meta$retained_original_threshold),'individual labels:',uniqueN(meta$individual),'\n')
cat('Completed descriptive analysis. RPKM was not treated as raw counts; Bulk columns were excluded from single-cell analyses.\n')
sink()
