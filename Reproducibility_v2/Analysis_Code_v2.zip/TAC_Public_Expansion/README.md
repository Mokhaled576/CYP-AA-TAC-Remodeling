# Cardiac pressure-overload public-data expansion

Downloads and new computational analyses are complete. All biological analyses ran locally in Rscript. Original project files were preserved.

## Start here

- documents/Lipidomics_Analysis_Report.md: latest lipid context, sensitivity and limits.
- documents/Reorganized_Paper_and_4week_Test.md: evidence hierarchy and targeted four-week results.
- documents/Analysis_Report.md: earlier four-dataset findings and statistical boundaries.
- documents/Expanded_Manuscript_Working_Draft.docx: the expanded manuscript, including Figures 8–9.
- documents/Expanded_Supplement_Working_Draft.docx: original S1–S68 plus new S69–S73.
- documents/Response_to_Reviewers_With_Lipidomics.docx: latest response draft.

The Word files are working drafts. Structure, text, embedded images and file readability were checked; final Word pagination has not been visually verified. Author review, journal formatting and public archive updating remain pending. Nothing was submitted, uploaded or emailed.

## Completed analyses

| Dataset | Completed analysis |
|---|---|
| bfry768hk7 | Three-week lipid context; 799 features, 5 Sham/5 TAC; all-feature limma, annotation audit and normalization/influence sensitivity; no named EET/DHET/HETE data |
| GSE296709 | Four-week sorted endothelial bulk RNA; 3 source WT-labeled Sham and 5 TAC; all-gene edgeR QL, detection and leave-one-out sensitivity |
| GSE120064 | 11,492 cells, 16 individual labels; lineage pseudobulk, nuclear-gene TMM/edgeR, QC reconciliation, source-group and cell-support sensitivity |
| GSE95140 | 482 mouse cardiomyocytes, 396 passing original QC; 12 individual labels; descriptive individual-level RPKM evaluation |
| PXD061784 | 5,344 protein records; 4,113 eligible; time-matched unpaired early-TAC limma comparisons and normalization sensitivity |
| GSE262690 | 114,288 nuclei, 20 people; patient/lineage pseudobulk, unadjusted, age/sex-adjusted and AS9-excluded models |

The earlier GSE308859 discovery and GSE155882/GSE270896 external analyses remain in the sibling Supporting_Analyses folder; their findings are retained and qualified in the expansion draft. No estrogen mechanism or sex-specific biological effect was analyzed.

## Scientific interpretation

The expansion adds evidence but does not uniformly confirm the original findings. Independent cardiomyocyte Ephx2 decreases and modest early protein evidence are compartment/time-specific. Broader mouse lineage patterns are heterogeneous. No adjusted test for the six highlighted human genes in the four highlighted lineages passes global FDR 0.05. These data must not be represented as universal replication or established metabolic activity.

## Reproduce in RStudio

Open Expansion.Rproj, then source scripts/run_analyses.R. Read results/integrity_checks.csv and the logs after completion. Scripts also run with Rscript and absolute paths. Existing aggregation caches avoid repeated large input parsing; a clean copy without the two aggregation caches reconstructs them from source.

scripts/00_prepare_inputs.R extracts the outer gzip layer of the human RDS if needed. Published age/sex values were extracted from Supplementary Data 6 by extract_published_clinical.py; the 20-patient CSV is supplied with provenance. build_expansion_report.py regenerates the reports and Word drafts from result tables and preserved source_documents. R software versions and sessions are recorded in logs.

## Provenance

acquisition_manifest.csv records input sources, sizes and SHA-256 hashes. file_manifest.csv inventories the reproducibility ZIP. Input downloads remain in data on the laptop; the compact ZIP excludes data to avoid duplicating nearly 2 GB. source_documents preserves the previous revision used as the document baseline.

results/download_status.csv records historical command-line failures before browser acquisition succeeded; acquisition_manifest.csv supersedes that status. preparation_audit.txt and DOWNLOADS_NEEDED.md describe current status or are clearly marked historical. No security settings were changed.

## Remaining limits

Discovery animal/section replication; spatial Ephx2 cellular origin; anatomical matching; baseline age/time confounding in mice; count/metadata differences on three GSE120064 plates; unverified PI/API metadata-category meanings; narrow CYP protein coverage; human age, donor and clinical confounding; direct activity and oxylipin validation. Computational expansion cannot eliminate these experimental limits.
