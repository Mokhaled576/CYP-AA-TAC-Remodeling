# Supplementary Data 2 and 3

Supplementary Data 2 contains result tables from both analysis stages. It does not contain newly collected experimental data.

| Manuscript table group | File prefix in Supporting_Analyses/tables |
|---|---|
| R1 Discovery QC and depth sensitivity | 01_ |
| R2 Broad CYP detectability | 02_ |
| R3 Ephx2 spatial and captured-cell diagnostics | 03_ |
| R4 Spatial models and blocked prediction | 04_ |
| R5 Earlier external cohorts | 05_ |
| R6 Cohort characteristics | 06_ |
| R7 Target-excluded transcript programs | 07_ |

TAC_Public_Expansion/results contains accession-prefixed tables for GSE120064, GSE95140, GSE296709, GSE262690 and PXD061784, and Lipidomics-prefixed tables for bfry768hk7. The acquisition manifest records source URLs, sizes and SHA-256 checksums. Historical download failures are retained as history, not current download status.

Supplementary Data 3 contains the R analysis code and source-table extraction helpers. The earlier revision scripts require the processed discovery/external Seurat objects in the original project tree; set TAC_SOURCE_DIR to that tree. These objects are not bundled here. Source data accessions and acquisition manifest are supplied. Exact original preparation scripts and raw data should accompany the final archived repository release. The current code bundle alone is not represented as an independently verified clean-room reconstruction of the discovery pipeline.

The expansion can be opened through Expansion.Rproj and scripts/run_analyses.R. It requires raw source inputs in TAC_Public_Expansion/data and the supplied clinical/frozen tables. These approximately 2-GB source inputs remain on the laptop and at the original repositories and are excluded from this compact package. The R scripts were executed during the analysis; the original revision's new configurable-path wrapper was syntax-checked but has not been rerun against a relocated project.

The formatting step changed document presentation and figure numbering, without changing biological model outputs. Original figure 7 becomes submission Figure 10; original figure 10 becomes submission Figure 7; original Figures 8 and 9 retain their numbers. Earlier reviewer-response cross-references may follow the pre-formatting numbering and are supplied only for author review.
